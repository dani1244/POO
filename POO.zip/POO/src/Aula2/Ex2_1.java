package Aula2;

import java.util.Scanner;

public class Ex2_1 {

   public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.println("Km? ");

    try {
      //  Block of code to try
      double km = input.nextDouble(); // ler os dados
   

      double milhas = (km / 1.609);  // converter
      System.out.println(milhas);

    }
    catch(Exception e) {
      //  se der erro
      System.out.println("os dados que inserio não são válidos.\nTente novamante");
    }

   }
    
}
