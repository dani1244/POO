package Aula2;

import java.util.Scanner;
public class Ex2_6 {
    public static void main(String[] args) {
        int segundos, h, m, s;
        Scanner user_input = new Scanner(System.in);
        System.out.println("Introduza o tempo em segundos:");
        segundos = user_input.nextInt();

        h = segundos / 3600;
        m = (segundos % 3600) / 60;
        s = (segundos % 3600) % 60;

        System.out.println(h+"h:"+m+"m:"+s+"s");
        
    }
}
