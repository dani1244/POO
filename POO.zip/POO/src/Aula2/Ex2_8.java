package Aula2;
import java.util.Scanner;
import java.math.*;
public class Ex2_8 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);
        Double a, b, c;

        //ler os dados dos catetos
        System.out.println("introduza o cateto A: ");
        a = Math.pow(user_input.nextDouble(), 2) ;
        System.out.println("Introduza o cateto B: ");
        b = Math.pow(user_input.nextDouble(), 2) ;
        
        // calcular a hipotenusa
        c = Math.sqrt(a+b);

        //calcular o ângulo entre a e c
        Double ang = Math.toRadians(a/c);
        double angulo = Math.toDegrees(Math.sin(ang));

        System.out.println("O valor da hipotenusa é: " + c);
        System.out.println("o vlaor do ângulo: "+angulo);
    }
}
