package Aula2;

import java.util.Scanner;

public class Ex2_4 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);
        double montante, juro, montante_final;

        System.out.print("introduza o montante investido:");
        montante = user_input.nextDouble();
        System.out.print("indique o juro:");
        juro = user_input.nextDouble() / 100;


        Double mes1, mes2, mes3;
        mes1 = (juro*montante) + montante;
        System.out.println("mes1"+mes1);
        mes2 = (juro*mes1) + mes1;
        System.out.println("mes1"+mes2);
        mes3 = (juro*mes2) + mes2;
        System.out.println("mes1"+mes3);

        montante_final = mes3;
        System.out.println(montante_final);

    }
}
