package Aula2;
import java.util.Scanner;
import java.math.*;
import java.text.DecimalFormat;
public class Ex2_5 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);
        float v1, d1, v2, d2, vm;

        System.out.println("Introduza a distância em Km \ne a velociade em Km/h");
        System.out.print("Indique a V1: ");
        v1 = user_input.nextFloat();
        System.out.print("Indique a d1: ");
        d1 = user_input.nextFloat();
        System.out.print("Indique a V2: ");
        v2 = user_input.nextFloat();
        System.out.print("Indique a d2: ");
        d2= user_input.nextFloat();

        vm = (d1+d2)/((d1/v1)+(d2/v2));

        //arrendondar o valor
        BigDecimal bd = new BigDecimal(vm).setScale(2, RoundingMode.HALF_EVEN);

        System.out.println(bd.doubleValue()+ " Km/h");
    }
}
