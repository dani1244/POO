package Aula2;

import java.util.Scanner;
import java.math.*;

public class Ex2_7 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);
        int x1, y1, x2, y2;

        System.out.println("Introduza os dados separados por vírgula.\nEx: 2,4 sendo (x,y)");

        // ler os valores
        System.out.print("Introduza X do ponto P1: ");
        x1 = user_input.nextInt();
        System.out.print("Introduza Y do ponto P1: ");
        y1 = user_input.nextInt();
        System.out.print("Introduza X do ponto P2: ");
        x2 = user_input.nextInt();
        System.out.print("Introduza Y do ponto P2: ");
        y2 = user_input.nextInt();

        // calcular distância
        double distancia = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));

        System.out.println("A distância é: " + distancia);

    }
}