package Aula2;

import java.util.Scanner;

public class Ex2_3 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);
        double M, ini, fim, Q;

        try {

            System.out.println("Introduza a quantidade da água: ");
            M = user_input.nextDouble();
            System.out.println("Introduza as temperaturas em Celsius!");

            System.out.println("Introduza a temperatura inicial:");
            ini = user_input.nextDouble();

            System.out.println("Introduza a temperatura final:");
            fim = user_input.nextDouble();

            // calcular a energia

            Q = (M * (fim - ini)) * 4184;
            System.out.println("A energia necessária é :" + Q);
        } catch (Exception e) {
            System.out.println("Os dados introduzidos estão incorretos!\n");
        }

    }
}
