package Aula2;

import java.util.Scanner;

public class Ex2_2 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);
        System.out.println("Qual é a temperatura em Célsius? ");

        try {
            double C = user_input.nextDouble(); // ler o input

            double F = (1.8 * C) + 32;
            System.out.println(F + "F");

        } catch (Exception e) {
            // se der erro

            System.out.println("os dados introduzidos estão incorretos.\nIntroduza novamente os dados.");

        }

    }
}
