package Aula3;

import java.io.IOException;
import java.lang.ProcessBuilder.Redirect.Type;
import java.math.*;
import java.text.DecimalFormat;
import java.util.Scanner;

public class Ex3_1 {
    public static void main(String[] args) {
        DecimalFormat df = new DecimalFormat("#.#");
        df.setRoundingMode(RoundingMode.UP);

        double notaP, notaT, notaFinal;
        Scanner user_input = new Scanner(System.in);

        // pegar os valores e validar
        try {
            System.out.println("Introduza a notaP:");
            notaP = user_input.nextDouble();

            System.out.println("Introduza a notaT:");
            notaT = user_input.nextDouble();

            
            // calcular a nota final
            notaFinal = ((0.4 * notaT) + (0.6 * notaP));

            if (notaP < 7.0 || notaT < 7.0) {
                System.out.println("66 (reprovado por nota mínima)");
            } else {
                System.out.println("A nota final do aluno é: " + df.format(notaFinal));
            }
        } catch ( Exception e) {
            System.out.println("Os valores não foram inroduzidso corretamente.\nIntroduza-os novamente.");
        }

    }
}
