package Aula3;

import java.io.IOException;
import java.lang.ProcessBuilder.Redirect.Type;
import java.math.*;
import java.text.DecimalFormat;
import java.util.Scanner;

public class Ex3_8 {
    public static void main(String[] args) {
        DecimalFormat df = new DecimalFormat("#.#");
        df.setRoundingMode(RoundingMode.UP);

        double notaP, notaT, notaFinal;
        Scanner user_input = new Scanner(System.in);

        Double[][] turma = { { 11.3, 9.3 }, { 16.7, 5.1 }, { 7.8, 18.9 }, { 10.6, 15.9 }, { 16.9, 5.9 }, { 1.9, 12.7 },
                { 17.6, 4.8 }, { 0.7, 12.1 }, { 8.7, 8.6 }, { 19.2, 1.4 },
                { 17.5, 3.4 }, { 11.6, 11.4 }, { 7.2, 8.5 }, { 1.9, 1.4 }, { 19.3, 14.9 }, { 0.0, 12.1 }
        };

        // pegar os valores
        System.out.printf("%8s %8s %8s\n", "NotaT", "NotaT", "Media");
        for (int i = 0; i < turma.length; i++) {
            // System.out.println("NotaT: " + turma[i][0] + " NotaP: " + turma[i][1]);

            notaT = turma[i][0];

            notaP = turma[i][1];

            // calcular a nota final
            notaFinal = ((0.4 * notaT) + (0.6 * notaP));
            if (notaT < 7.0 || notaP < 7.0) {
                System.out.printf("%8.1f %8.1f %8s \n", notaT, notaP, "66");
            } else {
                System.out.printf("%8.1f %8.1f %8.0f \n", notaT, notaP, notaFinal);
            }

        }

    }
}
