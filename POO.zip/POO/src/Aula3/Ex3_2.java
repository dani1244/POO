package Aula3;
import java.util.Scanner;
public class Ex3_2 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);

        System.out.print("Introduza um número: ");
        int N = user_input.nextInt();  // N == numero
        
        for (int i = N; i >= 0; i--) {
            System.out.println(i);
        }
    }
}
