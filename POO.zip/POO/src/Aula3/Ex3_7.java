package Aula3;

import java.text.BreakIterator;
import java.util.Scanner;
import java.util.Random;

public class Ex3_7 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);

        int randomNum = (int) (Math.random() * 101);
        System.out.println(randomNum);

        System.out.print("Introduza a sua escolha: ");
        int userGuess = user_input.nextInt();

        if (userGuess == randomNum) {
            System.out.println("Acertou!");
            // System.exit(0);
        }
        int tentativas = 0;

        while (true) {
            do {

                System.out.print("Introduza a sua escolha: ");
                userGuess = user_input.nextInt();

                tentativas++;

                if (userGuess > randomNum) {
                    System.out.println("Demasiado alta!");
                } else if (userGuess < randomNum) {
                    System.out.println("Demasiado baixa!");

                }
            } while (userGuess != randomNum);
            System.out.println("Tentativas: " + tentativas);

            // pergunatar se pretende continuar
            System.out.println("Pretende continuar? Prima (S)im");
            String respota = user_input.next();

            if (!respota.equals("Sim") && !respota.equals("S")) {
                break;
            } else {
                randomNum = (int) (Math.random() * 101);  //voltar a gerar o numero aleatorio
                continue;
            }
        }

    }
}
