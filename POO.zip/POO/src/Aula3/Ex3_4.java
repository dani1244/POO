package Aula3;
import java.util.Scanner;

import javax.swing.text.AbstractDocument.LeafElement;
public class Ex3_4 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);
        String conjunto_texto = "";

        System.out.println("introduza o número: "); //ler o primeiro valor
        int valor1 = user_input.nextInt();
        conjunto_texto += valor1 ;
        String lista_string[]; //lista com os numeros 

        int ultimovalor = 0 ;

        // pedir os outros valores
        while (valor1 != ultimovalor) {
            System.out.println("introduza o número: ");
            int valor = user_input.nextInt();
            conjunto_texto += " "+valor;
            ultimovalor = valor;
            System.out.println(conjunto_texto);
        }


        lista_string = conjunto_texto.split(" "); // converter em arrays
        //System.out.println(lista_string);


        // montar um novo array com os numeros em int
        int[] valores = new int[lista_string.length];
        for (int i = 0; i < lista_string.length; i++) {
            valores[i] = Integer.parseInt(lista_string[i]);
            //System.out.println(s[i]);
        }

        // ler os numeros da lista de int

        int maior = 0; //maior valor da lista
        int menor = valores[0];
        int soma = 0;
        for (int i = 0; i < valores.length; i++) {
            //determinar o máximo
            if (valores[i] > maior) {
                maior = valores[i];
            }
            //determinar o mínimo
            if (valores[i] < menor) {
                menor = valores[i];
            }

            soma += valores[i]; //somar os valores

        }
        //determinar a média 
        Double media = Double.valueOf(soma/valores.length);

        System.out.println("Máximo: "+maior+"\nMínimo: "+menor+"\nMédia: "+media+"\nTotal de número lidos: "+valores.length );
    }
}
