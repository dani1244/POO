package Aula3;

import java.util.Scanner;

public class Ex3_6 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);

        System.out.println("introduza a data no formato mm-yyyy, ex 03-2022: ");

        String data_texto = user_input.nextLine();
        String data_string[]; // lista com a data em string

        data_string = data_texto.split("-");

        int mes = Integer.parseInt(data_string[0]);// tranformar o mes em int
        int ano = Integer.parseInt(data_string[1]);// transformar o ano me int
        int dias = 30;

        // verificar se é bissexto
        if (((ano % 4 == 0) && (ano % 100 != 0 || ano % 400 == 0))) {
            switch (mes) {
                case 02:
                    dias = 29;
                    break;
                case 04:
                    dias = 30;
                    break;
                case 06:
                    dias = 30;
                    break;
                case 9:
                    dias = 30;
                    break;
                case 11:
                    dias = 30;
                    break;

                default:
                    dias = 31;
                    break;

            }

        } else {
            switch (mes) {
                case 02:
                    dias = 28;
                    break;
                case 04:
                    dias = 30;
                    break;
                case 06:
                    dias = 30;
                    break;
                case 9:
                    dias = 30;
                    break;
                case 11:
                    dias = 30;
                    break;

                default:
                    dias = 31;
                    break;

            }

        }

        System.out.println("O mês tem: "+dias);
    }
}
