package Aula3;

import java.util.Scanner;
import java.text.DecimalFormat;
import java.math.*;
public class Ex3_5 {
    public static void main(String[] args) {
        Scanner user_inpput = new Scanner(System.in);

        System.out.println("Montante ?");
        Double montante = user_inpput.nextDouble();
        if ((montante < 0) || ((montante % 1000) != 0)) {
            while ((montante < 0) || ((montante % 1000) != 0)) {
                System.out.println("O montate precisa ser positivo e multiplo de 1000");
                System.out.println("Montante ?");
                montante = user_inpput.nextDouble();
            }
        }

        System.out.println("Juro ?");
        Double juro_pretendido = user_inpput.nextDouble();
        if ((juro_pretendido < 0) || (juro_pretendido > 5)) {
            while ((juro_pretendido < 0) || (juro_pretendido > 5)) {
                System.out.println("O juro deve ser um valor entre 0% e 5%");
                System.out.println("Juro ?");
                juro_pretendido = user_inpput.nextDouble();
            }
        }

        //System.out.println("montante: " + montante + "\njuro: " + juro_pretendido);

        // calcular o valor mensal em 12 meses
        double juro = juro_pretendido / 100;
        Double lastmes = 0.0; // mês passado
        
        for (int i = 0; i < 12; i++) {
            lastmes = (juro*montante)+montante;
            montante = lastmes;
            //System.out.println(lastmes);
        }
        Double juroFinal = lastmes;

        //arredondar o valor:
        BigDecimal jF = new BigDecimal(juroFinal).setScale(3, RoundingMode.HALF_EVEN);

        System.out.println("Juro final: "+jF.doubleValue());


    }
}
