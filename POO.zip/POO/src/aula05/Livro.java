package aula05;

// classe livro
public class Livro {
    // atributos
    private String titulo;
    private String tipoEmprestimo;
    private Boolean disponibilidade = true;
    // gerar ID
     
    static int nId = 100;
    int id = 0;

    public Livro(String titulo, String tipoEmprestimo) {
        this.titulo = titulo;
        this.tipoEmprestimo = tipoEmprestimo.toUpperCase();

        this.id = nId;
        nId++;
    }
    public Livro(String titulo){
        this.titulo = titulo;
        this.tipoEmprestimo = "NORMAL";
        this.id = nId;
        nId++;
    }

    // metodos

    public int getId() {
        return this.id;
    }

    public boolean getDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(boolean disponibilidade) {
        this.disponibilidade = disponibilidade;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTipoEmprestimo() {
        return tipoEmprestimo;
    }

    public void setTipoEmprestimo(String tipoEmprestimo) {
        this.tipoEmprestimo = tipoEmprestimo;
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "Livro: " + id + ", " + titulo + ", " + tipoEmprestimo;
    }

}
