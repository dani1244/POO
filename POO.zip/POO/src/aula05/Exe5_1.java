package aula05;

import java.util.Scanner;

import aula07.Exe7_2.DateYMD;

public class Exe5_1 {

    public static void main(String[] args) {

        Scanner user_input = new Scanner(System.in);

        DateYMD user_data = new DateYMD(2, 3, 2022);

        while (true) {
            System.out.println("Date operations: ");
            System.out
                    .println(
                            "1 - create new date\n2 - show current date\n3 - increment date\n4 - decrement date\n0 - exit");
            int operacao = user_input.nextInt();

            // criar nova data
            if (operacao == 1) {
                System.out.println("insira o dia: ");
                int dia = user_input.nextInt();
                System.out.println("Insira o mês: ");
                int mes = user_input.nextInt();
                System.out.println("Insira o ano: ");
                int ano = user_input.nextInt();

                if (user_data.valid(dia, mes, ano)) { // se a data for válida
                    user_data.setData(dia, mes, ano);
                    System.out.println("date created!");
                } else {
                    System.out.println("A data introduzida não é válida!");
                }
            }

            // mostrar data atual
            if (operacao == 2) {
                System.out.println(user_data.toString());
            }

            // incementar data atual
            if (operacao == 3) {
                user_data.incrementarData();
                System.out.println(user_data);
            }

            // decrementar data atual
            if (operacao == 4) {
                user_data.decrementarData();
                System.out.println(user_data);
            }

            // terminar programa
            if (operacao == 0)
                break;
        }

    }

}
