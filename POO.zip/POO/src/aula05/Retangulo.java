package aula05;

/**
 * Retangulo
 */
public class Retangulo {
    /**
     *
     */
    Double comprimento, altura;

    public Retangulo(Double comprimento, Double altura) {
        if (validarRetangulo(comprimento, altura)) {
            this.comprimento = comprimento;
            this.altura = altura;
        } else {
            System.out.println("O valor introduzido não é válido");
        }

    }

    // area do retangulo
    public double area() {
        return comprimento * altura;
    }

    // determinar o perimetro
    public Double perimetro() {

        return 2 * (this.altura * this.comprimento);
    }

    public Double getComprimento() {
        return comprimento;
    }

    public void setComprimento(Double comprimento) {

        if (validarSet(comprimento)) {
            this.comprimento = comprimento;
        } else {
            System.out.println("O valor introduzido não é válido");
        }
    }

    public Double getAltura() {
        return altura;
    }

    public void setAltura(Double altura) {
        if (validarSet(altura)) {
            this.altura = altura;
        } else {
            System.out.println("O valor introduzido não é válido");
        }

    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "Comprimento: " + comprimento + " Altura: " + altura;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Retangulo other = (Retangulo) obj;
        if (!getEnclosingInstance().equals(other.getEnclosingInstance()))
            return false;
        if (altura == null) {
            if (other.altura != null)
                return false;
        } else if (!altura.equals(other.altura))
            return false;
        if (comprimento == null) {
            if (other.comprimento != null)
                return false;
        } else if (!comprimento.equals(other.comprimento))
            return false;
        return true;
    }

    private Object getEnclosingInstance() {
        return null;
    }

    // validar retangulo
    static boolean validarRetangulo(Double comp, Double alt) {
        boolean valido = false;

        if (comp >= 0 && alt >= 0) {
            valido = true;
        }

        return valido;
    }

    // validar SETs
    static boolean validarSet(Double valor) {
        boolean valido = true;
        if (valor < 0) {
            valido = false;
        }
        return valido;
    }

}
