package aula05;

import java.util.ArrayList;
// classe utilizador
public class Utilizador {

    // atributos
    private String nome;
    private int nMec;
    private String curso;
    private ArrayList<Integer> livros = new ArrayList<Integer>(); //lista de livros emprestados

    public Utilizador(String nome, int nMec, String curso) {
        this.nome = nome;
        this.nMec = nMec;
        this.curso = curso;
    }

    //metodos
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getnMec() {
        return nMec;
    }

    public void setnMec(int nMec) {
        this.nMec = nMec;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }
    public void setLivros(int IdDoLivro) {
        this.livros.add(IdDoLivro);
    }

    public ArrayList getLivros() {
        return livros;
    }    
    
    //remover livro da lista dos livros emprestados pelo utilizador
    public void removerLivroDaLista(int bookId) {

        for (int i = 0; i < this.livros.size(); i++) {
            System.out.println(livros.get(i).getClass());
            if (this.livros.get(i) == bookId) {
                this.livros.remove(i);
            }
        }
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "Aluno: "+nMec+", "+nome+", "+curso;
    }
}
