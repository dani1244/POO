package aula05;

import java.time.Year;
import java.util.Scanner;

public class Exe5_2 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);

        Calendario novo_calendario = new Calendario(2021, 4);
        while (true) {

            try {

                System.out.println("1 - create new calendar\n2 - print calendar month\n3 - print calendar\n0 - exit");

                int escolha = user_input.nextInt();

                if (escolha == 1) {
                    System.out.println("Introduza o ano: ");
                    int ano = user_input.nextInt();
                    System.out.println("OBS:dia da semana de 1-7\nDia da semana em que o ano começa: ");
                    int diaSemana = user_input.nextInt();

                    if (validarCalendario(ano, diaSemana)) {
                        novo_calendario = new Calendario(ano, diaSemana);
                        System.out.println("Calendario criado!");
                    } else {
                        System.out.println("Operação não executada!");
                    }

                }
                if (escolha == 2) {
                    System.out.println("Os meses são de 1-12.");
                    System.out.println("Introduza o mês: ");
                    int mes = user_input.nextInt();

                    if (validarMes(mes)) {
                        novo_calendario.printMonth(mes);
                    } else {
                        System.out.println("Operação não realizada!");
                    }

                }
                if (escolha == 3) {
                    novo_calendario.toString();
                }

                if (escolha == 0) {
                    break;
                }

            } catch (Exception e) {
                System.out.println("As opções devem ser numeros inteiros!");
            }

        }

    }

    static boolean validarCalendario(int ano, int dia) {
        Boolean valido = true;

        if (!(ano > 0 && (dia > 0 && dia <= 7))) {
            valido = false;
        }

        return valido;

    }

    static boolean validarMes(int mes) {
        boolean valido = true;

        if (!(mes > 0 && mes <= 12)) {
            valido = false;
        }
        return valido;
    }
}
