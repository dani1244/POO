package aula05;

import java.math.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Exe5_3 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);

        ArrayList<Circulo> circulos = new ArrayList<>();
        ArrayList<Triangulo> triangulos = new ArrayList<>();
        ArrayList<Retangulo> retangulos = new ArrayList<>();

        while (true) {

            try {

                System.out.println(
                        "1 - criar circulo\n2 - criar triangulo\n3 - criar retangulo\n4 - listar circulos\n5 - listar triangulos\n6 - listar retangulos\n7 - comparar os circulos\n8 - comparar os triangulos\n9 - comparar os retangulos\n0 - sair");
                int opcao = user_input.nextInt();
                user_input.nextLine();

                // criar circulos
                if (opcao == 1) {
                    System.out.println("Introduza o raio!");
                    double raio = user_input.nextDouble();
                    if (Circulo.validarRaio(raio)) {
                        circulos.add(new Circulo(raio));
                    } else {
                        System.out.println("O dado introduzido no raio não é válido!");
                    }
                }

                // triangulos
                if (opcao == 2) {
                    System.out.println("Lado 1: ");
                    double lado1 = user_input.nextDouble();
                    System.out.println("Lado 2: ");
                    double lado2 = user_input.nextDouble();
                    System.out.println("Lado 3: ");
                    double lado3 = user_input.nextDouble();
                    if (Triangulo.validartriangulo(lado1, lado2, lado3)) {
                        triangulos.add(new Triangulo(lado1, lado2, lado3));
                    } else {
                        System.out.println("Os valores introduzidos não satisfazem a desigualdade triângular!");
                    }

                }
                // retangulo
                if (opcao == 3) {
                    System.out.println("Comprimento:");
                    double comprimento = user_input.nextDouble();
                    System.out.println("Altura: ");
                    double altura = user_input.nextDouble();

                    if (Retangulo.validarRetangulo(comprimento, altura)) {
                        retangulos.add(new Retangulo(comprimento, altura));
                    } else {
                        System.out.println("Os dados não são válidos");
                    }

                }

                // imprimir lista circulos
                if (opcao == 4) {
                    for (int i = 0; i < circulos.size(); i++) {
                        System.out.println("Circulo " + i + " " + circulos.get(i));
                    }
                }

                // imprimir lista de triangulos
                if (opcao == 5) {
                    for (int i = 0; i < triangulos.size(); i++) {
                        System.out.println("Triângulo " + i + " " + triangulos.get(i));
                    }
                }
                // imprimir lista de retangulos
                if (opcao == 6) {
                    for (int i = 0; i < retangulos.size(); i++) {
                        System.out.println("Retangulo " + i + " " + retangulos.get(i));
                    }
                }

                // comparar os circulo
                if (opcao == 7) {
                    System.out.println("Indique o index do objeto listado ex: 0");
                    System.out.println("Index do circulo 1: ");
                    int circulo1 = user_input.nextInt();
                    user_input.nextLine();
                    System.out.println("Index do circulo 2: ");
                    int circulo2 = user_input.nextInt();
                    user_input.nextLine();

                    try {

                        Circulo c1 = circulos.get(circulo1);
                        Circulo c2 = circulos.get(circulo2);

                        if (c1.equals(c2)) {
                            System.out.println("São iguais!");
                        } else {
                            System.out.println("Não são iguais!");
                        }
                    } catch (Exception e) {
                        System.out.println("Verifique se os circulos exitem");
                    }

                }

                // comparar os triangulo
                if (opcao == 8) {

                    System.out.println("Indique o index do objeto listado ex: 0");
                    System.out.println("Index do triângulo 1: ");
                    int triangulo1 = user_input.nextInt();
                    user_input.nextLine();
                    System.out.println("Index do triângulo 2: ");
                    int triangulo2 = user_input.nextInt();
                    user_input.nextLine();

                    try {

                        Circulo t1 = circulos.get(triangulo1);
                        Circulo t2 = circulos.get(triangulo2);

                        if (t1.equals(t2)) {
                            System.out.println("São iguais!");
                        } else {
                            System.out.println("Não são iguais!");
                        }
                    } catch (Exception e) {
                        System.out.println("Verifique se os triãngulos exitem");
                    }
                }

                // comparar os retangulos
                if (opcao == 9) {
                    System.out.println("Indique o index do objeto listado ex: 0");
                    System.out.println("Index do retangulo 1: ");
                    int retangulo1 = user_input.nextInt();
                    user_input.nextLine();
                    System.out.println("Index do retangulo 2: ");
                    int retangulo2 = user_input.nextInt();
                    user_input.nextLine();

                    try {

                        Circulo r1 = circulos.get(retangulo1);
                        Circulo r2 = circulos.get(retangulo2);

                        if (r1.equals(r2)) {
                            System.out.println("São iguais!");
                        } else {
                            System.out.println("Não são iguais!");
                        }
                    } catch (Exception e) {
                        System.out.println("Verifique se os circulos exitem");
                    }
                }

                if (opcao == 0) {
                    break;
                }

            } catch (Exception e) {
                System.out.println("As opções devem ser numeros inteiros!");
            }
        }

    }
    

}
