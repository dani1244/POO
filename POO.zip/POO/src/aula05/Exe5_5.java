package aula05;

import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.text.Utilities;

public class Exe5_5 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);

        ArrayList<Utilizador> utilizadores = new ArrayList<>();
        ArrayList<Livro> livros = new ArrayList<>();

        while (true) {

            System.out.println(
                    "1 - inscrever utilizador\n2 - remover utilizador\n3 - imprimir lista de utilizadores\n4 - registar um novo livro\n5 - imprimir lista de livros\n6 - emprestar\n7 - devolver\n8 - sair");

            int escolha = user_input.nextInt();
            user_input.nextLine();

            // inscrever novo utilizador
            if (escolha == 1) {
                if (verificarEspaco(utilizadores)) {
                    System.out.println("Insira o Nome: ");
                    String nome = user_input.nextLine();
                    System.out.println("Insira o nMec: ");
                    Integer numero = user_input.nextInt();
                    while (numero < 0) {
                        System.out.println("O numero não pode ser negativo!");
                        System.out.println("Insira o nMec: ");
                        numero = user_input.nextInt();
                    }
                    System.out.println("Insira o Curso: ");
                    String curso = user_input.next().toUpperCase();
                    utilizadores.add(new Utilizador(nome, numero, curso));

                } else {
                    System.out.println("Já tem 100 utilizadores Registrados!");
                }

            }

            // remover utilizador
            if (escolha == 2) {
                System.out.println("Numero mecanografico no utilizador: ");
                int numero = user_input.nextInt();

                for (int i = 0; i < utilizadores.size(); i++) {
                    if (numero == utilizadores.get(i).getnMec()) {
                        utilizadores.remove(i);
                        System.out.println("Utilizador removido");
                    } else {
                        System.out.println("Utilizador não encontrado");
                    }
                }
            }

            // imprimir lista de utilizadores
            if (escolha == 3) {
                for (int i = 0; i < utilizadores.size(); i++) {
                    System.out.println(utilizadores.get(i));
                }
            }

            // registar novo livro
            if (escolha == 4) {
                if (verificarEspaco(livros)) {
                    System.out.println("Insira o Titulo: ");
                    String titulo = user_input.nextLine();

                    System.out.println("Insira o tipo de Emprestimo: ");
                    String tipo = user_input.nextLine();

                    livros.add(new Livro(titulo, tipo));
                } else {
                    System.out.println("Já possui 100 livros registrados!");
                }

            }

            // imprimir lista de livros
            if (escolha == 5) {
                for (int i = 0; i < livros.size(); i++) {
                    System.out.println(livros.get(i));
                }
            }

            // emprestar livro
            if (escolha == 6) {

                try {

                    System.out.println("Introduza o ID do livro: ");
                    int id = user_input.nextInt();
                    System.out.println("Introduza o nMec: ");
                    int nmec = user_input.nextInt();

                    // pegar a posição do user
                    int posicaoDoUser = 0;
                    for (int i = 0; i < utilizadores.size(); i++) {

                        if (utilizadores.get(i).getnMec() == nmec) {
                            posicaoDoUser = i;
                        }
                    }

                    // pegar a posição do book
                    int posicaoDoBook = 0;
                    for (int i = 0; i < livros.size(); i++) {

                        if (livros.get(i).getId() == id) {
                            posicaoDoBook = i;
                        }
                    }
                    // ver o numero de livros emprestados
                    if (utilizadores.get(posicaoDoUser).getLivros().size() < 3) {

                        if (livros.get(posicaoDoBook).getTipoEmprestimo().equals("CONDICIONAL")) {
                            System.out.println("O livro não pode ser requisitado!");
                        } else {
                            if (livros.get(posicaoDoBook).getDisponibilidade() == false) {
                                System.out.println("O livro não está disponível no momento");
                            } else {

                                // adicionar o livro a lista
                                utilizadores.get(posicaoDoUser).setLivros(id);
                                livros.get(posicaoDoBook).setDisponibilidade(false);
                                System.out.println("Emprestimo do livro ralizado!");
                            }
                        }
                    } else {
                        System.out.println(
                                "já emprestou 3 livros\nprecisa devolver ao menos 1 \npara voltar a emprestar");
                    }
                    // System.out.println("user: " + posicaoDoUser);
                    // System.out.println("book: " + posicaoDoBook);

                } catch (Exception e) {
                    System.out.println("--> Verifique se os dados introduzidos existem");
                }

            }

            // devolver o livro
            if (escolha == 7) {

                try {

                    System.out.println("Introduza o ID do livro: ");
                    int id = user_input.nextInt();
                    System.out.println("Introduza o nMec: ");
                    int nmec = user_input.nextInt();

                    // pegar a posição do user
                    int posicaoDoUser = 0;
                    for (int i = 0; i < utilizadores.size(); i++) {

                        if (utilizadores.get(i).getnMec() == nmec) {
                            posicaoDoUser = i;
                        }
                    }

                    // pegar a posição do book
                    int posicaoDoBook = 0;
                    for (int i = 0; i < livros.size(); i++) {

                        if (livros.get(i).getId() == id) {
                            posicaoDoBook = i;
                        }
                    }
                    // System.out.println(utilizadores.get(posicaoDoUser).getLivros());
                    utilizadores.get(posicaoDoUser).removerLivroDaLista(id); // remover da lista de livros emprestado
                    livros.get(posicaoDoBook).setDisponibilidade(true);

                } catch (Exception e) {
                    System.out.println("--> Verifique se os dados introduzidos existem");
                }

            }

            if (escolha == 8) {
                break;
            }

        }
    }

    // função para verificar o espaço de um vetor
    // o vetor tem que ter no máximo 100 utilizadores/livros
    static boolean verificarEspaco(ArrayList array) {
        boolean espaco = true;

        if (array.size() == 100) {
            espaco = false;
            System.out.println("limite de espaço alcançado!");
        }
        return espaco;
    }
}
