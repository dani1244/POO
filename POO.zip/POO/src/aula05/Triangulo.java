package aula05;

/**
 * Triangulo
 */
public class Triangulo {
    /**
     *
     */
    Double lado1, lado2, lado3;

    public Triangulo(Double lado1, Double lado2, Double lado3) {
        if (validartriangulo(lado1, lado2, lado3)) {
            this.lado1 = lado1;
            this.lado2 = lado2;
            this.lado3 = lado3;
        } else {
            System.out.println("Os valores introduzidos não satisfazem \na desigualdade triângular!");
        }

    }

    // determianr a area do triângulo
    public double area() {
        double soma_lados = lado1 + lado2 + lado3;
        return (soma_lados) / 2;
    }

    // determinar o perimetro
    public double perimetro() {
        return lado1 + lado2 + lado3;
    }

    public Double getLado1() {
        return lado1;
    }

    public void setLado1(Double lado1) {

        if (validarSet(lado1)) {
            this.lado1 = lado1;
        } else {
            System.out.println("O valor introduzido não é válido");
        }
    }

    public Double getLado2() {
        return lado2;
    }

    public void setLado2(Double lado2) {

        if (validarSet(lado2)) {
            this.lado2 = lado2;
        } else {
            System.out.println("O valor introduzido não é válido");
        }
    }

    public Double getLado3() {
        return lado3;
    }

    public void setLado3(Double lado3) {

        if (validarSet(lado3)) {
            this.lado3 = lado3;
        } else {
            System.out.println("O valor introduzido não é válido");
        }
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "lado1: " + lado1 + " lado2: " + lado2 + " lado3: " + lado3;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Triangulo other = (Triangulo) obj;
        if (!getEnclosingInstance().equals(other.getEnclosingInstance()))
            return false;
        if (lado1 == null) {
            if (other.lado1 != null)
                return false;
        } else if (!lado1.equals(other.lado1))
            return false;
        if (lado2 == null) {
            if (other.lado2 != null)
                return false;
        } else if (!lado2.equals(other.lado2))
            return false;
        if (lado3 == null) {
            if (other.lado3 != null)
                return false;
        } else if (!lado3.equals(other.lado3))
            return false;
        return true;
    }

    private Object getEnclosingInstance() {
        return null;
    }

    
    // validar triangulo
    static boolean validartriangulo(Double lado1, Double lado2, Double lado3) {
        boolean valido = false;

        if (((lado1 + lado2) > lado3) && ((lado2 + lado3) > lado1) && ((lado1 + lado3) > lado2)) {
            valido = true;
        }

        return valido;
    }
    
    // validar SETs
    static boolean validarSet(Double valor) {
        boolean valido = true;
        if (valor < 0) {
            valido = false;
        }
        return valido;
    }



}
