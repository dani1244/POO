package aula05;

import aula07.Exe7_2.DateYMD;

public class Calendario {

    // atributos
    int year, firstWeekdayOfYear, dia = 1, mes = 1;

    DateYMD nova_data;

    public Calendario(int ano, int firstWeekdayOfYear) {
        this.year = ano;
        this.firstWeekdayOfYear = firstWeekdayOfYear;
        this.nova_data = new DateYMD(1, 1, ano);
    }

    // metodos
    public int getYear() {
        return this.year;
    }

    public int getfirstWeekdayOfYear() {
        return this.firstWeekdayOfYear;
    }

    public int firstWeekdayOfMonth(int moth) {
        DateYMD dataTemp = new DateYMD(this.nova_data.getDia(), this.nova_data.getMes(), this.nova_data.getAno());
        int diaDaSemana = firstWeekdayOfYear;

        while (dataTemp.getMes() < moth) {

            dataTemp.incrementarData();
            diaDaSemana++;

            if (diaDaSemana == 8) {
                diaDaSemana = 1;
            }

        }
        // System.out.println(dataTemp.toString());

        return diaDaSemana;
    }


    public void printMonth(int month) {
        int semana = this.firstWeekdayOfMonth(month);

        System.out.printf("\t %s %d\n", mesEmString(month), this.year);

        System.out.printf("%s %3s %3s %3s %3s %3s %3s\n", "Su", "Mo", "Tu", "We", "Th", "Fr", "Sa");

        // primieros espaços
        String initialSpace = "";
        for (int i = 1; i < firstWeekdayOfMonth(month); i++) {
            initialSpace += "    ";
        }
        System.out.print(initialSpace);

        // preencher o calendário
        // mostrar os dias do mês começando de 1
        int diaMaximoDoMes = nova_data.monthDays(month, this.year);
        
        for (int i = 0, dia_do_mes = 1; dia_do_mes <= diaMaximoDoMes; i++) {
            for (int j = ((i == 0) ? semana - 1 : 0); j < 7 && (dia_do_mes <= diaMaximoDoMes); j++) {
                System.out.printf("%3d ", dia_do_mes);
                dia_do_mes++;
            }
            System.out.println();
        }

    }


    @Override
    public String toString() {
        
        for (int i = 1; i <= 12; i++) {
            this.printMonth(i);
            System.out.println("\n");
        }


        return "Calendário Completo";
    }

    //retornar o mes em string
    public static String mesEmString(int mes) {

        String mes_do_ano = "";

        switch (mes) {
            case 1:
                mes_do_ano = "January";
                break;
            case 2:
                mes_do_ano = "February";
                break;
            case 3:
                mes_do_ano = "March";
                break;
            case 4:
                mes_do_ano = "April";
                break;
            case 5:
                mes_do_ano = "May";
                break;
            case 6:
                mes_do_ano = "June";
                break;
            case 7:
                mes_do_ano = "July";
                break;
            case 8:
                mes_do_ano = "August";
                break;
            case 9:
                mes_do_ano = "September";
                break;
            case 10:
                mes_do_ano = "October";
                break;
            case 11:
                mes_do_ano = "November";
                break;
            case 12:
                mes_do_ano = "December";
                break;

        }
        

        return  mes_do_ano;
    }



}