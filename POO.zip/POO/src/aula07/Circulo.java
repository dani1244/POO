package aula07;

public class Circulo extends Forma {

    Double raio;
    

    public Circulo(Double raio) {
        if (validarRaio(raio)) {
            this.raio = raio;
        } else {
            System.out.println("O valor introduzido não é válido");
        }

    }

    // determinar a area do circulo
    public double area() {
        return Math.PI * (Math.pow(raio, 2));
    }

    // determinar o perimetro
    public double perimetro() {

        return (2 * Math.PI) * raio;
    }

    public Double getRaio() {
        return raio;
    }

    public void setRaio(Double raio) {

        if (validarSet(raio)) {
            this.raio = raio;
        } else {
            System.out.println("O valor introduzido não é válido");
        }
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "raio: " + this.raio+" Cor: "+this.getCor();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Circulo other = (Circulo) obj;
        if (raio == null) {
            if (other.raio != null)
                return false;
        
        
        }else if (!this.getCor().equals(other.getCor())){
            return false;
        } else if (!raio.equals(other.raio))
            return false;
        return true;
    }

    // validar o raio
    static boolean validarRaio(Double raio) {
        boolean valido = true;
        if (raio < 0) {
            valido = false;
        }
        return valido;
    }

    // validar SETs
    static boolean validarSet(Double valor) {
        boolean valido = true;
        if (valor < 0) {
            valido = false;
        }
        return valido;
    }

}
