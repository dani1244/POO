package aula07.Exe7_4;

public class Robo extends ObjetoMovel{
    String id, tipoDeJogador;
    int numeroDeGolosMarcados;

    public Robo(String id, String tipoDeJogador) {
        super(0, 0);
        this.id = id;
        this.tipoDeJogador = tipoDeJogador;
    }

    public void marcarGolo() {
        this.numeroDeGolosMarcados++;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTipoDeJogador() {
        return tipoDeJogador;
    }

    public void setTipoDeJogador(String tipoDeJogador) {
        this.tipoDeJogador = tipoDeJogador;
    }

    public int getNumeroDeGolosMarcados() {
        return numeroDeGolosMarcados;
    }

    public void setNumeroDeGolosMarcados(int numeroDeGolosMarcados) {
        this.numeroDeGolosMarcados = numeroDeGolosMarcados;
    }
    @Override
    public String toString() {
        return "robô " + id + ", numeroDeGolosMarcados = " + numeroDeGolosMarcados + ", tipoDeJogador: "
                + tipoDeJogador + super.toString();
    }
}
