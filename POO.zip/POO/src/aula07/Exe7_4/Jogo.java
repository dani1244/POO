package aula07.Exe7_4;

public class Jogo {
    Equipa[] equipa = new Equipa[2];

    Bola bola = new Bola("verde");
    int duracao = 5000;

    int tempodecorrido = 0;

    

    public Jogo(Equipa[] equipa, Bola bola, int duracao) {
        this.equipa = equipa;
        this.bola = bola;
        this.duracao = duracao;
    }

    public Jogo(Equipa equipa1, Equipa equipa2, Bola bola, int duracao) {
        this.equipa[0] = equipa1;
        this.equipa[1] = equipa2;
        this.bola = bola;
        this.duracao = duracao;
    }

    public Equipa[] getEquipa() {
        return equipa;
    }

    public void setEquipa(Equipa[] equipa) {
        this.equipa = equipa;
    }

    public Bola getBola() {
        return bola;
    }

    public void setBola(Bola bola) {
        this.bola = bola;
    }

    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    public int getTempodecorrido() {
        return tempodecorrido;
    }

    public void setTempodecorrido(int tempodecorrido) {
        this.tempodecorrido = tempodecorrido;
    }

    private void atualizarGolos() {
        equipa[1].setTotalDeGolosSofridos(equipa[0].getTotalDeGolosMarcados()); 

        equipa[0].setTotalDeGolosSofridos(equipa[1].getTotalDeGolosMarcados()); 
    
    }

    @Override
    public String toString() {
        String team = "";
        try {
                    for (int i = 0; i <= equipa.length; i++) {
            team += equipa[i].toString()+"\n";
        }
        } catch (Exception e) {
            System.out.println("não existe equipa!");
        }

        return "Jogo\n"+team+" \nbola = " + bola + ", duracao = " + duracao + ", tempodecorrido = " + tempodecorrido ;
    }
}
