package aula07.Exe7_4;

import java.lang.Math;

public class ObjetoMovel {
    int x, y;
    Double distanciaPercorida = 0.0;

    // construtor
    public ObjetoMovel(int newX, int newY) {

        this.x = newX;
        this.y = newY;
    }

    public void move(int newX, int newY) {
        // calcular a distância percorrida
        double d = Math.sqrt((Math.pow((newX - x), 2)) + (Math.pow((newY - y), 2)));

        distanciaPercorida += d;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Double getDistanciaPercorida() {
        return distanciaPercorida;
    }

    @Override
    public String toString() {
        return "DistanciaPercorida = " + distanciaPercorida + ", x = " + x + ", y = " + y;
    }

}
