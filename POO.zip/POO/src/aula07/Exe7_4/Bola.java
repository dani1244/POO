package aula07.Exe7_4;

public class Bola {
    String cor;

    public Bola(String cor) {
        this.cor = cor;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    @Override
    public String toString() {
        return "Cor:" + cor ;
    }
}
