package aula07.Exe7_4;

public class Exe7_4 {
    public static void main(String[] args) {
        Robo robo1 = new Robo("001", "Avancado");
        System.out.println(robo1.getDistanciaPercorida());

    }
}
