package aula07.Exe7_4;

import java.util.HashSet;
import java.util.Set;


public class Equipa {
    String nome, nomeDoResponsavel;
    int totalDeGolosMarcados, totalDeGolosSofridos;
    Set<Robo> listadeRobos = new HashSet<>();
    
    public Equipa(String nome, String nomeDoResponsavel) {
        this.nome = nome;
        this.nomeDoResponsavel = nomeDoResponsavel;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNomeDoResponsavel() {
        return nomeDoResponsavel;
    }

    public void setNomeDoResponsavel(String nomeDoResponsavel) {
        this.nomeDoResponsavel = nomeDoResponsavel;
    }

    public int getTotalDeGolosMarcados() {
        this.totalDeGolosMarcados();
        return totalDeGolosMarcados;
    }

    public void setTotalDeGolosMarcados(int totalDeGolosMarcados) {
        this.totalDeGolosMarcados = totalDeGolosMarcados;
    }

    public int getTotalDeGolosSofridos() {
        return totalDeGolosSofridos;
    }

    public void setTotalDeGolosSofridos(int totalDeGolosSofridos) {
        this.totalDeGolosSofridos = totalDeGolosSofridos;
    }

    public Set<Robo> getListadeRobos() {
        return listadeRobos;
    }

        //adicionar um robo à lista 
    public void setListadeRobos(Robo robo) {
        this.listadeRobos.add(robo);
    }


    private void totalDeGolosMarcados() {
        for (Robo robo : listadeRobos) {
            this.totalDeGolosMarcados += robo.getNumeroDeGolosMarcados();
        }
    }



    @Override
    public String toString() {
        return  nome + ", nomeDoResponsavel: " + nomeDoResponsavel + ", totalDeGolosMarcados = "
                + totalDeGolosMarcados + ", totalDeGolosSofridos = " + totalDeGolosSofridos ;
    }
}
