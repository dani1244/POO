package aula07.Exe7_3;

import java.util.ArrayList;
import java.util.Scanner;

public class Exe7_3 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);

        Agencia agencia = new Agencia("Nome da Agência de Viagens", "Endereço da Agência");

        System.out.println(
                "1 - listar dados da empresa\n2 - listar Alojamentos\n3 - listar quartos\n4 - listar carros\n5 - Adicionar apartamento\n6 - adicionar quarto de hotel\n7 - Adicionar carro\n8 - alterar o nome da agência\n9 - alterar o endereço\n0 - sair");

        int opcao = user_input.nextInt();

        while (opcao != 0) {

            try {

                    //iprimir os dados da Agência
                if (opcao == 1) {
                    agencia.toString();
                }

                //Listar os 
                if (opcao == 2) {
                    System.out.println("Lista de Alojamentos:\n");

                    for (Alojamento i : agencia.getListaDeAlojamentos()) {
                        System.out.println(i.toString());
                    }
                }


                if (opcao == 4) {
                    System.out.println("Lista de carros:\n");

                    for (Carro i : agencia.getListaDeCarros()) {
                        System.out.println(i.toString());
                    }
                }

                // Adicionar apartamentos
                if (opcao == 5) {
                    System.out.println("Código do apartamento:");
                    String codigo = user_input.nextLine();
                    System.out.println("Nome do apartamento:");
                    String nome = user_input.nextLine();
                    System.out.println("Localização do apartamento:");
                    String local = user_input.nextLine();
                    System.out.println("Preço por noite:");
                    Double preco = user_input.nextDouble();
                    System.out.println("Avalição do apartamento:");
                    Double avaliacao = user_input.nextDouble();
                    System.out.println("Disponibilidade do apartamento:");
                    Boolean disponibilidade = user_input.nextBoolean();
                    System.out.println("Número de quartos do apartamento:");
                    int quartos = user_input.nextInt();

                    Apartamento apartamento = new Apartamento(codigo, nome, local, preco, avaliacao, disponibilidade,
                            quartos);
                    agencia.insertAlojamento(apartamento);
                }


                    // Adicionar quartos
                if (opcao == 6) {
                    try {
                        System.out.println("Código do apartamento:");
                        String codigo = user_input.nextLine();
                        System.out.println("Nome do apartamento:");
                        String nome = user_input.nextLine();
                        System.out.println("Localização do apartamento:");
                        String local = user_input.nextLine();
                        System.out.println("Preço por noite:");
                        Double preco = user_input.nextDouble();
                        System.out.println("Avalição do apartamento:");
                        Double avaliacao = user_input.nextDouble();
                        System.out.println("Disponibilidade do apartamento:");
                        Boolean disponibilidade = user_input.nextBoolean();
                        System.out.println("Tipo de apartamento:");
                        String tipo = user_input.nextLine().toLowerCase();

                        if (!tipo.equals("single") || !tipo.equals("double") || !tipo.equals("twin")
                                || !tipo.equals("triple")) {
                            System.out.println("tipo incorreto!");
                        } else {

                            Quarto quarto = new Quarto(codigo, nome, local, preco, avaliacao, disponibilidade, tipo);
                            agencia.insertAlojamento(quarto);
                        }
                    } catch (Exception e) {
                        System.out.println("Dados incorretos!");
                    }

                }

                // Adicionar carros
                if (opcao == 7) {
                    try {
                        System.out.println("Classe do carro:");
                        char classe = user_input.next().charAt(0);
                        user_input.nextLine();
                        System.out.println("Tipo de carro:");
                        String tipo = user_input.next();
                        user_input.nextLine();

                        if ((tipo.equals("gasolina") || tipo.equals("diesel") || tipo.equals("hibrido")
                                || tipo.equals("eletrico")) && Carro.validarClasse(classe)) {

                            Carro carro = new Carro(classe, tipo);
                            agencia.insertCarro(carro);
                            System.out.println("---Carro adicionado!---");
                            break;
                        } else {
                            System.out.println("dados incorretos!");
                        }
                    } catch (Exception e) {
                        System.out.println("Dados incorretos!");
                    }

                }

                // terminar o programa
                if (opcao == 0) {

                    break;
                }

            } catch (Exception e) {
                System.out.println("As opções devem ser numeros inteiros!");
            }
        }
    }
}
