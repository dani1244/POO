package aula07.Exe7_3;

public class Apartamento extends Alojamento {

    int numero_de_quartos;

   
    public Apartamento(String codigo, String nome, String local, double preco_por_noite, double avaliacao, boolean disponibilidade ,int numero_de_quartos) {
        this.codigo = codigo; this.nome = nome; this.local = local; this.preco_por_noite = preco_por_noite; this.avaliacao = avaliacao; this.disponibilidade = disponibilidade;this.numero_de_quartos = numero_de_quartos;
    }


    public void check_in() {
        
    }

 
    public void check_out() {
        
    }


    public int getNumero_de_quanrtos() {
        return numero_de_quartos;
    }


    public void setNumero_de_quanrtos(int numero_de_quanrtos) {
        this.numero_de_quartos = numero_de_quanrtos;
    }
    
}
