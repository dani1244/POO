package aula07.Exe7_3;

public class Quarto extends Alojamento {

    String tipo;

    public Quarto(String codigo, String nome, String local, double preco_por_noite, double avaliacao, boolean disponibilidade ,String tipo) {

        if (validarTipoDeQuarto(tipo) && validarAvaliacao(avaliacao)) {
            this.codigo = codigo; this.nome = nome; this.local = local; this.preco_por_noite = preco_por_noite; this.avaliacao = avaliacao; this.disponibilidade = disponibilidade;this.tipo = tipo;
        } else {
            System.out.println("Os dados inseridos não são validos!");
        }
        
    }

    public void check_in() {

    }

    public void check_out() {

    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public static boolean validarTipoDeQuarto(String tipo) {

        if (!tipo.equals("single") || !tipo.equals("double") || !tipo.equals("twin") || !tipo.equals("triple")){
            return false;
        }

        return true;
    }
    public static boolean validarAvaliacao(double avaliacao) {

        if (avaliacao<1 || avaliacao > 5) {
            return false;
        }
        return true;
    }
}
