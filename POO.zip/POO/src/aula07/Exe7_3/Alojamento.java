package aula07.Exe7_3;

public abstract class Alojamento {
    
    String codigo, nome, local;
    double preco_por_noite, avaliacao;
    boolean disponibilidade;

    public abstract void check_in();
    
    public abstract void check_out();



    // getters e setters 
    public String getCodigo() {
        return codigo;
    }
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getLocal() {
        return local;
    }
    public void setLocal(String local) {
        this.local = local;
    }
    public double getPreco_por_noite() {
        return preco_por_noite;
    }
    public void setPreco_por_noite(double preco_por_noite) {
        this.preco_por_noite = preco_por_noite;
    }
    public double getAvaliacao() {
        return avaliacao;
    }
    public void setAvaliacao(double avaliacao) {
        this.avaliacao = avaliacao;
    }
    public boolean isDisponibilidade() {
        return disponibilidade;
    }
    public void setDisponibilidade(boolean disponibilidade) {
        this.disponibilidade = disponibilidade;
    }
}
