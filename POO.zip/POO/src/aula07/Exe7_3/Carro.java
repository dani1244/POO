package aula07.Exe7_3;

public class Carro {

    char classe;
    String tipo;
    boolean disponibilidade = true;

    public Carro(char classe, String tipo) {
        this.classe = classe;
        this.tipo = tipo;
    }

    public void levantar() {
        this.disponibilidade = false;

    }

    public void entregar() {
        this.disponibilidade = true;
    }

    public char getClasse() {
        return classe;
    }

    public void setClasse(char classe) {
        this.classe = classe;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo.toUpperCase();
    }


    //validar classe
    public static boolean validarClasse(char chara) {

        if (chara >= 'a' && chara <= 'f') {
            return true;
        }else{
            return false;
        }
    }

    @Override
    public String toString() {
        return "Classe:" + classe + ", tipo: " + tipo;
    }
}
