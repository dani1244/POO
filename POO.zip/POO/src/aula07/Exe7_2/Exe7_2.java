package aula07.Exe7_2;

import java.util.Scanner;

public class Exe7_2 {

    public static void main(String[] args) {
        
        
        Scanner user_input = new Scanner(System.in);

        DateYMD user_data = new DateYMD(24, 5, 2022);
        DateYMD user_data2 = user_data;

        DateND dataDias = new DateND(user_data);
        System.out.println("classe ND: "+dataDias);
        System.out.println(dataDias.dataFinal);
      
        System.out.println("Distância: "+dataDias.getDistancia());


       
        System.out.println(user_data);

        Date datateste = new DateND(2, 3, 2022);
        datateste.toString();
        System.out.println(datateste.getDia());
        System.out.println(datateste.getMes());
        System.out.println(datateste.getAno());

        while (true) {

            System.out.println("Date operations: ");
            System.out
                    .println(
                            "1 - create new date\n2 - show current date\n3 - increment date\n4 - decrement date\n0 - exit");
            int operacao = user_input.nextInt();

            // criar nova data
            if (operacao == 1) {
                System.out.println("insira o dia: ");
                int dia = user_input.nextInt();
                System.out.println("Insira o mês: ");
                int mes = user_input.nextInt();
                System.out.println("Insira o ano: ");
                int ano = user_input.nextInt();

                if (user_data.valid(dia, mes, ano)) { // se a data for válida
                    user_data.setData(dia, mes, ano);
                    System.out.println("date created!");
                } else {
                    System.out.println("A data introduzida não é válida!");
                }
            }

            // mostrar data atual
            if (operacao == 2) {
                System.out.println(user_data.toString());
            }

            // incementar data atual
            if (operacao == 3) {
                user_data.incrementarData();
                System.out.println(user_data);
            }

            // decrementar data atual
            if (operacao == 4) {
                user_data.decrementarData();
                System.out.println(user_data);
            }

            // terminar programa
            if (operacao == 0)
                break;
        }


    }
}
