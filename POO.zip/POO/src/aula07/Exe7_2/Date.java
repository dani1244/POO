package aula07.Exe7_2;

public abstract class Date implements Comparable<Date> {

    public int dia, mes, ano;


    protected Date(int dia, int mes, int ano) {
        if (valid(dia, mes, ano)) {

            
            this.dia = dia;
            this.mes = mes;
            this.ano = ano;

        } else {
            System.out.println("A data introduzida não é válida");
        }
    }


    // criar uma nova data
    public void setData(int dia, int mes, int ano) {
        if (valid(dia, mes, ano)) {

            this.dia = dia;
            this.mes = mes;
            this.ano = ano;

        } else {
            System.out.println("A data introduzida não é válida");
        }

    }

    // consultar o valor do dia
    public int getDia() {
        return dia;
    }

    // consultar o mês
    public int getMes() {
        return mes;
    }

    // consultar o ano
    public int getAno() {
        return ano;
    }

    // ver se o mes é valido
    public Boolean validMonth(int month) {

        Boolean valido = true;
        int mes = month;

        if (mes > 12 || mes < 1) {
            valido = false;
        }

        return valido;
    }

    // ver se o ano é bissexto
    public Boolean leapYear(int ano) {

        boolean bissexto = false;

        if (((ano % 4 == 0) && (ano % 100 != 0 || ano % 400 == 0))) {
            bissexto = true;
        }

        return bissexto;

    }

    // calcular o numero de dias do mes
    public int monthDays(int mes, int ano) {

        int dias = 0;

        // verificar se o ano é bissexto
        if (((ano % 4 == 0) && (ano % 100 != 0 || ano % 400 == 0))) {
            switch (mes) {
                case 02:
                    dias = 29;
                    break;
                case 04:
                    dias = 30;
                    break;
                case 06:
                    dias = 30;
                    break;
                case 9:
                    dias = 30;
                    break;
                case 11:
                    dias = 30;
                    break;

                default:
                    dias = 31;
                    break;

            }

        } else {
            switch (mes) {
                case 02:
                    dias = 28;
                    break;
                case 04:
                    dias = 30;
                    break;
                case 06:
                    dias = 30;
                    break;
                case 9:
                    dias = 30;
                    break;
                case 11:
                    dias = 30;
                    break;

                default:
                    dias = 31;
                    break;

            }

        }

        return dias;

    }

    // ver se a data é válida
    public Boolean valid(int dia, int mes, int ano) {
        boolean valido = false;

        if ((monthDays(mes, ano) >= dia && dia >= 1) && (validMonth(mes)) && ano >= 0) {
            valido = true;
        }

        return valido;

    }

    // incrementar a data
    public void incrementarData() {

        if (dia < monthDays(mes, ano)) {
            this.dia++;
        } else if ((dia == monthDays(mes, ano)) && mes < 12) {
            this.dia = 1;
            this.mes++;

        } else if ((dia == monthDays(mes, ano)) && mes == 12) {
            this.dia = 1;
            this.mes = 1;
            this.ano++;
        }

    }

    // decrementar a data
    public void decrementarData() {
        if ((dia <= monthDays(mes, ano)) && mes > 1) {
            if (dia > 1) {
                this.dia--;
            } else {
                this.dia = monthDays(mes - 1, ano);
                this.mes--;
            }

        } else if ((dia == 1 && mes > 1)) {

            this.dia = monthDays(mes - 1, ano);
            this.mes--;

        } else if ((dia > 1 && mes == 1)) {

            this.dia--;

        } else if ((dia == 1 && mes == 1)) {

            if (ano > 0) {
                this.dia = monthDays(mes - 1, ano);
                this.mes = 12;
                this.ano--;
            } else {
                System.out.println("Não é possivel decrementar");
            }

        }
    }
    

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + this.ano;
        result = prime * result + this.dia;
        result = prime * result + this.mes;
        return result;
    }
    
    @Override
    public int compareTo(Date o) {
        // comparar os datas

        int result = 0;

        if (ano != o.ano) {
            result = ano - o.ano;
        } else if (mes != o.mes) {
            result = mes - o.mes;
        } else {
            result = dia - o.dia;
        }

        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Date other = (Date) obj;
        if (ano != other.ano)
            return false;
        if (dia != other.dia)
            return false;
        if (mes != other.mes)
            return false;
        return true;
    }
    

    // Método toString

    @Override
    public String toString(){
        return  this.dia+"-"+this.mes+"-"+this.ano ; 
    }

}