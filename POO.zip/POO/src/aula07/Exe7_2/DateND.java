package aula07.Exe7_2;

public class DateND extends Date {

    private int distancia = 0;
    Date dataFinal;

    public DateND(DateYMD dataF) {
        super(dataF.getDia(), dataF.getMes(), dataF.getAno());
        this.dataFinal = dataF;

    }

    public DateND(int dia, int mes, int ano) {
        super(dia, mes, ano);
        this.dataFinal = new DateYMD(dia, mes, ano);

    }

    public int getDistancia() {
        
        this.distancia = calcularDias(dataFinal);
        return this.distancia;
    }



    // calcular a diatância entre duas datas
    public static int calcularDias(Date datacalcular) {
        Date dataModelo = new DateYMD(1, 1, 2000);

        int dias = 0;
        Date data = new DateYMD(datacalcular.getDia(),datacalcular.getMes(),datacalcular.getAno());


        if ((dataModelo.compareTo(data) < 0)) {

            while ((dataModelo.compareTo(data) < 0)) {
                dias++;
                data.decrementarData();

            }

        } else if ( (dataModelo.compareTo(data) > 0)){

            while ((dataModelo.compareTo(data) > 0)) {
                dias++;
                data.incrementarData();

            }

        }else {
            
           dias = 0;
        }

        return dias;
    }

}
