package aula07.Exe7_2;

public class DateYMD extends Date{


    public DateYMD(int dia, int mes, int ano) {
        super(dia, mes, ano);
    }


    // consultar o valor do dia
    public int getDia() {
        return dia;
    }

    // consultar o mês
    public int getMes() {
        return mes;
    }

    // consultar o ano
    public int getAno() {
        return ano;
    }



    















    
}
