package aula11;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.io.FileWriter;
import java.io.File;
import java.io.IOException;

public class Exe11_2 {
    public static void main(String[] args) throws FileNotFoundException {

        Map<String, String> companhias = new TreeMap<>();

        try (Scanner input = new Scanner(new FileReader("./POO/POO/src/aula11/companhias.txt"))) {

            input.nextLine(); // pular a primeira linha
            while (input.hasNext()) {
                String linha = input.nextLine();
                String[] companhia = linha.split("\t"); // split por tab
                companhias.put(companhia[0], companhia[1]);
                // System.out.println(word);

            }
        }

        // System.out.println(companhias);

        System.out.println("--------------------------Tabela de Voos--------------------------");
        Set<Voo> conjuntoVoos = new TreeSet<>();
        List<Voo> listaVoos = new ArrayList<>();
        try (Scanner input = new Scanner(new FileReader("./POO/POO/src/aula11/voos.txt"))) {

            input.nextLine();
            while (input.hasNext()) {
                String linha = input.nextLine();
                // System.out.println(linha);
                String[] companh = linha.split("\t");
                if (companh.length == 3) {
                    String sigla = companh[1].substring(0, 2);
                    String id = companh[1].substring(2, companh.length - 1);
                    // System.out.println(id);
                    String compa = companhias.get(sigla);
                    Voo voo = new Voo(companh[0], companh[1], compa, companh[companh.length - 1]);
                    listaVoos.add(voo);
                    conjuntoVoos.add(voo);
                } else {
                    String sigla = companh[1].substring(0, 2);
                    String id = companh[1].substring(2, companh.length - 1);
                    String compa = companhias.get(sigla);
                    Voo voo = new Voo(companh[0], companh[1], compa, companh[2], companh[3]);
                    listaVoos.add(voo);
                    conjuntoVoos.add(voo);

                }
            }

        } catch (Exception e) {
            System.out.println("error reading the file!");
        }
        System.out.println(
                "Ponto - a\n------------------------------------------------------------------------------------------------");
        System.out.printf("%s   %-10s  %-19s  %-25s  %-12s  %-7s%n", "Hora", "Voo", "Companhia", "Origem", "Atraso",
                "Previsto");

        for (Voo voo : listaVoos) {
            System.out.printf("%s  %-10s  %-19s  %-25s  %-12s  %-7s%n", voo.getHora(), voo.getVoo(), voo.getCompanhia(),
                    voo.getOrigem(), voo.getAtraso(), voo.getPrevisto());
        }

        // ponto b escrever no ficheiro

        try {
            File ficheiro = new File("./POO/POO/src/aula11/Infopublico.txt");
            if (ficheiro.createNewFile()) {
                System.out.println("File created: " + ficheiro.getName());
            } else {
                System.out.println("File already exists.");
            }

            // escrevendo no ficheiro
            System.out.println("wrinting in the file...");
            FileWriter myWriter = new FileWriter("./POO/POO/src/aula11/Infopublico.txt");
            myWriter.write(String.format("%s   %-10s  %-19s  %-25s  %-12s  %-7s%n", "Hora", "Voo", "Companhia",
                    "Origem", "Atraso",
                    "Previsto"));
            myWriter.write(
                    "---------------------------------------------------------------------------------------------\n");
            for (Voo voo : listaVoos) {
                myWriter.write(String.format("%s  %-10s  %-19s  %-25s  %-12s  %-7s%n", voo.getHora(), voo.getVoo(),
                        voo.getCompanhia(),
                        voo.getOrigem(), voo.getAtraso(), voo.getPrevisto()));
            }
            System.out.println("done !");
            myWriter.close();

        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        // ponto c -determinar a media de atrasos por companhia-
        System.out.println(
                "---------------------------------------------------------------------\nponto c - determinar a media de atrasos por companhia\n---------------------------------------------------------------------");
        //Map<String, List<Integer>> dadosCompanhias = new TreeMap<>((m1, m2) -> dadosCompanhias.get(m1).get(0) - dadosCompanhias.get(m2).get(0));
        Map<String, List<Integer>> dadosCompanhias = new TreeMap<>();

        for (Voo voo : listaVoos) {
            // System.out.println(voo.getCompanhia() + ":" + voo.getAtraso());
            if (voo.getAtraso().equals(" ")) {

                if (voo.getCompanhia() == null) {// resolver temporariamnte o problema da companhia ZI
                    continue;
                }
                if (dadosCompanhias.containsKey(voo.getCompanhia())) {
                    int valor = dadosCompanhias.get(voo.getCompanhia()).get(0) + voo.getTempoDeAtrasoEmSegundos();

                    int nvezes = dadosCompanhias.get(voo.getCompanhia()).get(1) + 1;

                    // somar o valor do tempo
                    dadosCompanhias.get(voo.getCompanhia()).set(0, valor);
                    dadosCompanhias.get(voo.getCompanhia()).set(1, nvezes);

                } else {
                    List<Integer> listaDados = new ArrayList<>();
                    // o primeiro index guarda a hora e o segundo guarda a iteração
                    listaDados.add(voo.getTempoDeAtrasoEmSegundos());
                    listaDados.add(1);
                    dadosCompanhias.put(voo.getCompanhia(), listaDados);
                }
                continue;
            } else {
                if (voo.getCompanhia() == null) {// resolver o problema da companhia ZI (esta compainha não esxiste na
                                                 // lista de compainhas)
                    continue;
                }
                if (dadosCompanhias.containsKey(voo.getCompanhia())) {
                    int valor = dadosCompanhias.get(voo.getCompanhia()).get(0) + voo.getTempoDeAtrasoEmSegundos();

                    int nvezes = dadosCompanhias.get(voo.getCompanhia()).get(1) + 1;

                    // somar o valor do tempo
                    dadosCompanhias.get(voo.getCompanhia()).set(0, valor);
                    dadosCompanhias.get(voo.getCompanhia()).set(1, nvezes);

                } else {
                    List<Integer> listaDados = new ArrayList<>();
                    // o primeiro index guarda a hora e o segundo guarda a iteração
                    listaDados.add(voo.getTempoDeAtrasoEmSegundos());
                    listaDados.add(1);
                    dadosCompanhias.put(voo.getCompanhia(), listaDados);
                }

            }
        }
        System.out.println("---------------------------------------------------------------------");
        System.out.printf("%-25s   %-20s%n", "Companhia", "Atraso");
        System.out.println("---------------------------------------------------------------------");
        System.out.println(dadosCompanhias);

        for (String companhia : dadosCompanhias.keySet()) {
            List<Integer> valor = (List<Integer>) dadosCompanhias.get(companhia);
            // System.out.println(valor);
            int media_de_valor = valor.get(0) / valor.get(1);

            int hora = media_de_valor / 3600;
            int minuto = (media_de_valor - (hora * 3600)) / 60;

            int tamanho = String.valueOf(hora).length();
            int tamanho2 = String.valueOf(minuto).length();
            String horaString = tamanho == 1 ? "0" + hora : "" + hora;
            String minutoString = tamanho2 == 1 ? "0" + minuto : "" + minuto;
            System.out.printf("%-25s   %-20s%n", companhia, horaString + ":" + minutoString);

        }

        // ponto d - determinar o numero de chegadas-
        System.out.println(
                "\n---------------------------------------------------------------------\nponto d - determinar total de chegadas em origem\n---------------------------------------------------------------------");
        Map<String, Integer> chegadas = new TreeMap<>();
        try (Scanner input = new Scanner(new FileReader("./POO/POO/src/aula11/voos.txt"))) {

            input.nextLine();
            while (input.hasNext()) {
                String linha = input.nextLine();
                String[] companh = linha.split("\t");
                if (companh.length == 3) {
                    // System.out.println(companh[companh.length - 1]);

                    if (chegadas.containsKey(companh[companh.length - 1])) {
                        int chega = chegadas.get(companh[companh.length - 1]) + 1;
                        chegadas.put(companh[companh.length - 1], chega);
                    } else {
                        chegadas.put(companh[companh.length - 1], 1);
                    }

                } else {
                    // System.out.println(companh[companh.length - 2]);

                    if (chegadas.containsKey(companh[2])) {
                        int chega = chegadas.get(companh[2]) + 1;
                        // System.out.println("o valor pego: "+chega);
                        chegadas.put(companh[2], chega);
                    } else {// System.out.println("entrou");
                        // System.out.println("O valor pego no lengh -1: "+companh[companh.length -
                        // 1]);System.out.println(companh.length);
                        chegadas.put(companh[2], 1);
                    }

                }

            }

        } catch (Exception e) {
            System.out.println("error reading the file!");
        }

        // sort por valor
        List<Map.Entry<String, Integer>> listaOrdenada = new ArrayList<>(chegadas.entrySet());

        Collections.sort(listaOrdenada, new Comparator<Map.Entry<String, Integer>>() {

            @Override
            public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {

                return o2.getValue() - o1.getValue();
            }

        });// fim da ordenação
        System.out.printf("%-25s   %-5s%n", "Origem", "Voos");
        System.out.println("---------------------------------------------------------------------");
        for (Map.Entry<String, Integer> chegada2 : listaOrdenada) {
            System.out.printf("%-25s   %-5d%n", chegada2.getKey(), chegada2.getValue());

        }

        /*
         * System.out.printf("%-25s   %-5s%n", "Origem", "Voos");System.out.println(
         * "---------------------------------------------------------------------");
         * for (String chegada : chegadas.keySet()) {
         * System.out.printf("%-25s   %-5d%n", chegada, chegadas.get(chegada));
         * 
         * }
         */
    }
}
