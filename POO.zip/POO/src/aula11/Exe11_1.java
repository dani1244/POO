package aula11;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Map.Entry;

public class Exe11_1 {
    public static void main(String[] args) throws FileNotFoundException {

        // "./POO/src/aula11/major.txt" para intellij
        // "./POO/POO/src/aula11/major.txt" para vs code

        ArrayList<String> listaDepalavras = new ArrayList<>();

        //ler as palavras e adicioná-las à lista
        try (Scanner input = new Scanner(new FileReader("./POO/POO/src/aula11/major.txt"))) {

            input.nextLine(); // pular a primeira linha

            // ler as palavras e adicionar na listaDePalavras
            while (input.hasNext()) {

                String str = input.next();

                String Regex = "[$&+,:;=?@#|'<>.“”`´‟„^*()%!‘’]";
                str = str.replaceAll(Regex, "");
                if (str.length() < 3) {
                    continue;
                } else {
                    listaDepalavras.add(str.toLowerCase());
                }
            }


        }

        Map<String, Map<String, Integer>> dict = new HashMap<String, Map<String, Integer>>();

        //ler palavras por par
        String[] string = { "", "" };
        //System.out.println(listaDepalavras.contains("1864")+", "+listaDepalavras.indexOf("1864"));

        int c = 0;
        for (String palavra : listaDepalavras) {
            if (c == 0) {
                string[0] = palavra;
                c++;
            } else {
                string[1] = palavra;
                c = 0;

                // verificar if the dict contains the first word
                if (!dict.containsKey(string[0])) {
                    Map<String, Integer> dict2 = new HashMap<>();
                    dict2.put(string[1], 1);
                    dict.put(string[0], dict2);
                } else {
                    Map<String, Integer> map2 = dict.get(string[0]);// segundo dicionário

                    if (!map2.containsKey(string[1])){
                        map2.put(string[1], 1);

                    }else{
                        int num = map2.get(string[1]);
                        num++;
                        map2.put(string[1], num);
                    }
                }
            }
        }

        //percorrer o dicionário
        for (Entry<String, Map<String, Integer>> string2 : dict.entrySet()) {
            System.out.println(string2.getKey()+"="+string2.getValue());
        }
    }
}
