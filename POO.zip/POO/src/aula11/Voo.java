package aula11;

public class Voo implements Comparable<Voo> {
    private String hora, voo, origem, atraso, previsto, companhia = " ";
    private int horaEmSegundo;
    private int horaInt;
    private int minutoInt;
    private int horaMinutoint;
    private int tempoSegundos;
    private int tempoDeAtrasoEmSegundos;

    public Voo(String hora, String voo, String companhia, String origem, String atraso) {
        this.hora = hora;
        this.voo = voo;
        this.origem = origem;
        this.atraso = atraso;
        this.companhia = companhia;

        // tratar das horas
        String[] hora1 = hora.split(":");
        this.horaInt = Integer.parseInt(hora1[0]); // transformar a hora em segundo
        this.minutoInt = Integer.parseInt(hora1[1]); // transformar minuto em segundo
        this.horaMinutoint = horaInt + minutoInt;

        this.tempoSegundos = (this.horaInt * 3600) + (this.minutoInt * 60);

        // atraso
        String[] horaAtraso = atraso.split(":");
        int horaAtrasoSeg = (Integer.parseInt(horaAtraso[0]) * 3600); // transformar a hora em segundo
        int minutoAtrasoSeg = (Integer.parseInt(horaAtraso[1]) * 60); // transformar minuto em segundo
        this.tempoDeAtrasoEmSegundos = horaAtrasoSeg + minutoAtrasoSeg;
        int tempoAtrasoSegundo = tempoDeAtrasoEmSegundos + tempoSegundos;
        int horaDeAtraso = tempoAtrasoSegundo / 3600;
        int minutoAtrasoss = (tempoAtrasoSegundo - (horaDeAtraso * 3600)) / 60;
        this.previsto = "Previsto: " + horaDeAtraso + ":" + minutoAtrasoss;
    }

    public Voo(String hora, String voo, String companhia, String origem) {
        this.hora = hora;
        this.voo = voo;
        this.origem = origem;
        this.companhia = companhia;
        this.atraso = " ";
        this.previsto = " ";

        String[] hora1 = hora.split(":");
        this.horaInt = Integer.parseInt(hora1[0]);
        this.minutoInt = Integer.parseInt(hora1[1]);
        this.horaMinutoint = horaInt + minutoInt;
    }

    
    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getVoo() {
        return voo;
    }

    public void setVoo(String voo) {
        this.voo = voo;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getAtraso() {
        return atraso;
    }

    public void setAtraso(String atraso) {
        this.atraso = atraso;
    }

    public String getPrevisto() {
        return previsto;
    }

    public void setPrevisto(String previsto) {
        this.previsto = previsto;
    }

    public String getCompanhia() {
        return companhia;
    }

    public void setCompanhia(String companhia) {
        this.companhia = companhia;
    }

    public int getHoraEmSegundo() {
        return horaEmSegundo;
    }

    public void setHoraEmSegundo(int horaEmSegundo) {
        this.horaEmSegundo = horaEmSegundo;
    }

    public int getHoraInt() {
        return horaInt;
    }

    public void setHoraInt(int horaInt) {
        this.horaInt = horaInt;
    }

    public int getMinutoInt() {
        return minutoInt;
    }

    public void setMinutoInt(int minutoInt) {
        this.minutoInt = minutoInt;
    }

    public int getHoraMinutoint() {
        return horaMinutoint;
    }

    public void setHoraMinutoint(int horaMinutoint) {
        this.horaMinutoint = horaMinutoint;
    }

    public int getTempoSegundos() {
        return tempoSegundos;
    }

    public void setTempoSegundos(int tempoSegundos) {
        this.tempoSegundos = tempoSegundos;
    }

    public int getTempoDeAtrasoEmSegundos() {
        return tempoDeAtrasoEmSegundos;
    }

    public void setTempoDeAtrasoEmSegundos(int tempoDeAtrasoEmSegundos) {
        this.tempoDeAtrasoEmSegundos = tempoDeAtrasoEmSegundos;
    }


    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        int horaSegundo = horaInt * 60;
        result = prime * result + horaSegundo;
        result = prime * result + horaMinutoint;
        result = prime * result + minutoInt;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Voo other = (Voo) obj;
        if (horaInt != other.horaInt)
            return false;
        if (horaMinutoint != other.horaMinutoint)
            return false;
        if (minutoInt != other.minutoInt)
            return false;
        return true;
    }

    @Override
    public int compareTo(Voo o) {
        // comparar os datas

        int result = 0;

        if (horaMinutoint > o.horaMinutoint) {
            result = 1;
        } else if (horaMinutoint < o.horaMinutoint) {
            result = -1;
        }
        return result;
    }

    @Override
    public String toString() {
        if (atraso == null) {

            return hora + "   " + voo + "   " + companhia + "   " + origem;
        } else {

            return hora + "   " + voo + "   " + companhia + "   " + origem + "   " + atraso + "   " + previsto;
        }
    }

}
