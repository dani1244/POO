package ExeTP;

public class testeTreino {
    public static void main(String[] args) {
        String s1 = "abcdefg";
        System.out.println(s1.matches("\\w{3,}"));

        String[] vec = {"aveiro", "22", "abril", "2020"};
    }
}
