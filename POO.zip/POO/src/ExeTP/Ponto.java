package ExeTP;

public class Ponto{
    double x, y, z;

    public Ponto(double x, double y, double z) {
        this.x= x;
        this.y= y;
        this.z= z;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }
    public double getZ() {
        return z;
    }
    public double[] getPonto() {
        double[] ponto = {x, y, z};
        return ponto;
    }
    
}