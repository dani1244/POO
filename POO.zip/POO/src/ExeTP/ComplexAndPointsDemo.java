package ExeTP;

public class ComplexAndPointsDemo {

    public static void main(String[] args) {

              // completar código
              Complexos complex1 = new Complexos(-2, 7);
              Complexos complex2 = new Complexos(-2, 0);
              System.out.println(complex1);
              System.out.println(complex2);

              Ponto point3D1 = new Ponto(1, 3, 1);
              Ponto point3D2 = new Ponto(2, 0, 4);

              Ponto point1 = new Ponto(1, 32, 1);
              Ponto point2 = new Ponto(28, 0, 4);
              Ponto point3 = new Ponto(1, 31, 1);
              Ponto point4 = new Ponto(12, 0, 15);
              Ponto point5 = new Ponto(1, 3, 1);
              Ponto point6 = new Ponto(2, 8, 4);
              Ponto point7 = new Ponto(7, 3, 17);
              Ponto point8 = new Ponto(3, 0, 4);
              Ponto point9 = new Ponto(1, 3, 1);
              Ponto point10 = new Ponto(0, 0, 47);

              Ponto[] vetorDePontos = {point1, point2, point3, point4, point5, point6, point7, point8, point9, point10};
              System.out.println(point1.getX());

    }

}
