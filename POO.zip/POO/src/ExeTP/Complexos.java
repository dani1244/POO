package ExeTP;

public class Complexos {
    double imaginaria, real;

    public Complexos(double imaginaria, double real) {
        this.imaginaria = imaginaria;
        this.real = real;
    }

    public double getImaginaria() {
        return imaginaria;
    }

    public double getReal() {
        return real;
    }

    @Override
    public String toString() {

        if (imaginaria == 0) {
            return ""+real ;
        }else if(real == 0){
            return imaginaria + "i";
        }
        return imaginaria + "i" + real ;
    }
   
}


