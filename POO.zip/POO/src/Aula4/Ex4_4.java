package Aula4;

import java.time.Year;
import java.util.Arrays;
import java.util.Scanner;

public class Ex4_4 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);

        System.out.println("Formato de data mês/ano/dia-da-semana\nDigite a data: ");
        String data_string = user_input.nextLine();
        lerValor(data_string);
        System.out.println(calculoDia(lerValor(data_string)));

        imprimirCalendario(calculoDia(lerValor(data_string)), lerValor(data_string));

    }

    // ler o valor
    private static String[] lerValor(String string) {

        String[] data = string.split("/");
        // System.out.println(Arrays.toString(data));

        return data;
    }

    // calculo de dias no mês
    private static int calculoDia(String[] data) {

        int mes = Integer.parseInt(data[0]);// tranformar o mes em int
        int ano = Integer.parseInt(data[1]);// transformar o ano me int
        int dias = 30;

        // verificar se é bissexto
        if (((ano % 4 == 0) && (ano % 100 != 0 || ano % 400 == 0))) {
            switch (mes) {
                case 02:
                    dias = 29;
                    break;
                case 04:
                    dias = 30;
                    break;
                case 06:
                    dias = 30;
                    break;
                case 9:
                    dias = 30;
                    break;
                case 11:
                    dias = 30;
                    break;

                default:
                    dias = 31;
                    break;

            }

        } else {
            switch (mes) {
                case 02:
                    dias = 28;
                    break;
                case 04:
                    dias = 30;
                    break;
                case 06:
                    dias = 30;
                    break;
                case 9:
                    dias = 30;
                    break;
                case 11:
                    dias = 30;
                    break;

                default:
                    dias = 31;
                    break;

            }

        }
        return dias;

    }

    private static String imprimirCalendario(int dia, String[] data) {

        int semana = Integer.parseInt(data[2]);

        int mes = Integer.parseInt(data[0]);

        int ano = Integer.parseInt(data[1]);

        System.out.println(PrintMesAno(mes, ano));

        System.out.printf("%s %3s %3s %3s %3s %3s %3s\n", "Su", "Mo", "Tu", "We", "Th", "Fr", "Sa");

        // primieros espaços
        String initialSpace = " ";
        for (int i = 1; i < semana; i++) {
            initialSpace += "    ";
        }
        System.out.print(initialSpace);
        

        // mostrar os dias do mês começando de 1
        for (int i = 0, dia_do_mes = 1; dia_do_mes <= dia; i++) {
            for (int j = ((i == 0) ? semana - 1 : 0); j < 7 && (dia_do_mes <= dia); j++) {
                System.out.printf("%3d ", dia_do_mes);
                dia_do_mes++;
            }
            System.out.println();
        }

        return "calendário";
    }

    private static String PrintMesAno(int mes_a, int ano_a) {

        String mes_do_ano = "";

        switch (mes_a) {
            case 1:
                mes_do_ano = "January";
                break;
            case 2:
                mes_do_ano = "February";
                break;
            case 3:
                mes_do_ano = "March";
                break;
            case 4:
                mes_do_ano = "April";
                break;
            case 5:
                mes_do_ano = "May";
                break;
            case 6:
                mes_do_ano = "June";
                break;
            case 7:
                mes_do_ano = "July";
                break;
            case 8:
                mes_do_ano = "August";
                break;
            case 9:
                mes_do_ano = "September";
                break;
            case 10:
                mes_do_ano = "October";
                break;
            case 11:
                mes_do_ano = "November";
                break;
            case 12:
                mes_do_ano = "December";
                break;

        }

        String retorno = String.format("\t %s %d", mes_do_ano, ano_a);

        return retorno;
    }

}
