package Aula4;
import java.util.Arrays;
import java.util.Scanner;
public class Ex4_1 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);
        System.out.println("Introduza a palavra/frase ou parágrafo: ");
        String frase = user_input.nextLine(); // receber a frase

        // minuscula
        String minuscula = frase.toLowerCase();
        System.out.println("O texto em minuscula: "+minuscula);

        // ultimo caracter
        //String ultimo = minuscula.substring(frase.length()-1);
        System.out.println("O último caracter: "+frase.charAt(frase.length()-1));

        // os três primeiros
        String tres = frase.substring(0, 3);
        System.out.println("Os 3 primeiros carateres: "+tres);

        //  Testar outros métodos
        // Ver se começa com A
        System.out.println("A frase começa com 'A': " + minuscula.startsWith("a"));

        // Ver se a frase termina com E
        System.out.println("A frase termina com 'E': " + minuscula.endsWith("e"));

        // ver se a frase conter "ar"
        System.out.println("A frase contém 'ar': "+ minuscula.contains("ar"));

        // método split
        // separar a frase pela letra "a"
        String[] splitFrase = frase.split("a");
        System.out.println("Split por 'a': "+Arrays.toString(splitFrase));
    }
}
