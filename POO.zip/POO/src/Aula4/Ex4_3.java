package Aula4;
import java.util.Scanner;
public class Ex4_3 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);

        System.out.println("Introduza uma frase: ");
        String frase = user_input.nextLine();

        String[] fraseSplit = frase.split(" ");
        StringBuilder acronimo = new StringBuilder();
        for (int i = 0; i < fraseSplit.length; i++) {
            if (fraseSplit[i].length() < 3)
            continue;

            acronimo.append(fraseSplit[i].charAt(0)); 

        }
        String acronimoString = acronimo.toString().toUpperCase();
        System.out.println("Acrónimo: "+acronimoString);
    }
}
