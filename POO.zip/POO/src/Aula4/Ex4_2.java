package Aula4;

import java.util.Scanner;
import java.util.*;
import java.lang.*;

public class Ex4_2 {
    public static void main(String[] args) {
        Scanner user_input = new Scanner(System.in);
        System.out.println("Digite a frase: ");
        String frase = user_input.nextLine();

        //imprimir o número de digitos
        System.out.println("Número de digitos: " + contarDigito(frase));
        //imprimir o numero de espaços
        System.out.println("Numero de espaços: " + contarEspaco(frase));
        // verificar se tem apenas minusculas
        System.out.println("Contém só minúsculas? " + contemMinuscula(frase));
        //verificar se tem espaços seguidos
        System.out.println("frase sem espaços seguidos: " +
                espacosSeguidos(frase));
        //verificar se a frase é um palíndromo
        System.out.println("A frase é um palíndromo: " + palindromo(frase));
    }

    // Contar o número de digitos
    private static int contarDigito(String frase) {
        int digitos = 0;
        for (int i = 0; i < frase.length(); i++) {
            if (frase.charAt(i) >= 48 && frase.charAt(i) <= 57) {
                digitos++;
            }
        }
        return digitos;
    }

    // contar o número de espaços
    private static int contarEspaco(String frase) {
        int espaco = 0;

        String s = frase;

        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == ' ')
                espaco++;
        }

        return espaco;

    }

    // ver se có ocntém minusculas
    private static Boolean contemMinuscula(String frase) {

        boolean contem = true;

        for (int i = 0; i < frase.length(); i++) {
            if (Character.isUpperCase(frase.charAt(i))) {
                contem = false;
            }
        }
        return contem;
    }

    // retirar espaços seguidos
    private static String espacosSeguidos(String frase) {
        StringBuilder nova_frase = new StringBuilder();
        nova_frase.append(frase.charAt(0));//adicionar a primeira letra
        for (int i = 1; i < frase.length(); i++) {
            if (frase.charAt(i) == ' ' && frase.charAt(i-1) == ' ') {
                continue;
            } else {
                nova_frase.append(frase.charAt(i));
                //System.out.println(nova_frase);
            }
        }
        String fraseNova = nova_frase.toString();
        return fraseNova;
    }

    // ver se a frase é um palíndromo

    private static Boolean palindromo(String frase) {

        Boolean resultado = true;

        String nova_frase = frase.toUpperCase().strip();
        String[] fraseSplit = nova_frase.split(" ");
        StringBuilder fraseJunta = new StringBuilder();
        for (int i = 0; i < fraseSplit.length; i++) {
            fraseJunta.append(fraseSplit[i]);
        }

        // variaveis para o inicio e fim da string
        int i = 0, j = fraseJunta.length() - 1;

        while (i < j) {

            // se as letras forem diferentes
            if (fraseJunta.charAt(i) != fraseJunta.charAt(j))
                resultado = false;

            i++;
            j--;
        }

        // Given string is a palindrome
        return resultado;
    }

}
