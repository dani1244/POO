package aula12;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Exe12_2 {
    public static void main(String[] args) {

        Set<Movie> conjuntnoDeMovies = new TreeSet<>();

        Set<Movie> conjuntnoMoviesscore = new TreeSet<>((m1, m2) -> (int) m2.getScore() - (int) m1.getScore());
        Set<Movie> conjuntnoMoviesnunning = new TreeSet<>(
                (m1, m2) -> (int) m1.getRunningTime() - (int) m2.getRunningTime());

        Set<String> generos = new TreeSet<>();

        Set<Movie> conjuntoMore60Score = new TreeSet<>();

        //ponto b
        try (Scanner input = new Scanner(new FileReader("./POO/POO/src/aula12/movies.txt"))) {

            input.nextLine();
            while (input.hasNext()) {
                String linha = input.nextLine();
                // System.out.println(linha);

                String[] movie = linha.split("\t"); // split por tab

                String nome = movie[0];
                double score = Double.parseDouble(movie[1]);
                String rating = movie[2];
                String genre = movie[3];
                int runningtime = Integer.parseInt(movie[4]);

                Movie filme = new Movie(nome, score, rating, genre, runningtime);

                conjuntnoDeMovies.add(filme);

                conjuntnoMoviesscore.add(filme);

                conjuntnoMoviesnunning.add(filme);

                generos.add(genre);

                if (score > 60) {
                    conjuntoMore60Score.add(filme);
                }

            }
        } catch (Exception e) {
            System.out.println("Ficheiro não encontrado!");
        }

        // listar por ordem nominal
        System.out.println();
        System.out.println("----------------------------------------------------------------------------------------");
        System.out.println("|                    ponto b - imprimir por ordem nominal                               |");
        System.out.println("----------------------------------------------------------------------------------------");
        printMovies(conjuntnoDeMovies);

        // listar por ordem decrescente de score ponto c

        System.out.println("----------------------------------------------------------------------------------------");
        System.out.println("\nListar por ordem decrescente de score\n");
        System.out.println("----------------------------------------------------------------------------------------");
        System.out.println("|        ponto c - imprimir por ordem decrescente de score e running time              |");
        System.out.println("----------------------------------------------------------------------------------------");
        System.out.println("  Listar por ordem decrescente de score                                                 ");
        System.out.println("----------------------------------------------------------------------------------------");
        printMovies(conjuntnoMoviesscore);

        // listar por ordem crescente de nunnig time
        System.out.println("----------------------------------------------------------------------------------------");
        System.out.println("  Listar por ordem crescente de nunnig time                                             ");
        System.out.println("----------------------------------------------------------------------------------------");
        printMovies(conjuntnoMoviesnunning);

        // listar os géneros disitintos
        System.out.println("----------------------------------------------------------------------------------------");
        System.out.println("|                 ponto d - imprimir os géneros distintos                              |");
        System.out.println("----------------------------------------------------------------------------------------");
        System.out.print("Lista de géneros: ");
        for (String string : generos) {
            System.out.print(", " + string);
        }

        // ponto e - excrever no ficheiro
        try (FileWriter myWriter = new FileWriter("./POO/POO/src/aula12/myselection.txt")) {
            // imprimir o cabeçalho
            myWriter.write(String.format("%-38s    %5s  %-10s  %10s  %5s  %n%n", "Name", "score", "rating", "genre",
                    "running time"));
            ;
            for (Movie movie : conjuntoMore60Score) {
                myWriter.write(String.format("%-38s    %5.2f  %-10s  %10s  %-5d  %n", movie.getNome(), movie.getScore(),
                        movie.getRating(), movie.getGenre(), movie.getRunningTime()));
            }

            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

    }

    // função para imprimir os dados do set
    public static void printMovies(Set<Movie> listadeMovie) {

        System.out.printf("%-38s    %5s  %-10s  %10s  %5s  %n%n", "Name", "score", "rating", "genre", "running time");
        for (Movie movie : listadeMovie) {
            System.out.printf("%-38s    %5.2f  %-10s  %10s  %-5d  %n", movie.getNome(), movie.getScore(),
                    movie.getRating(), movie.getGenre(), movie.getRunningTime());
        }
    }
}
