package aula12;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class Exe12_1 {
    public static void main(String[] args) throws FileNotFoundException {

        List<String> listaDeNomes = new ArrayList<>();
        Set<String> SetDeNomes = new TreeSet<>();
        int totalwords = 0;
        int diferentes = 0;

        try (Scanner input = new Scanner(new FileReader("./POO/POO/src/aula11/major.txt"))) {

            while (input.hasNext()) {

                String palavra = input.next().toLowerCase();

                String Regex = "[$&+,:;=?@#|'<>.“”`´‟„^*()%!‘’]";
                palavra = palavra.replaceAll(Regex, "");
                if (palavra.equals("-")) {
                    continue;
                }
                listaDeNomes.add(palavra);
                // colocar as palavras num conjunto
                SetDeNomes.add(palavra);
                totalwords++;

            }
        } catch (Exception e) {
            System.out.println("Ficheiro não encontrado!");
        }

        // remover as palavras que estão no set do dicionário
        for (String string : SetDeNomes) {
            listaDeNomes.remove(string);
        }

        for (String string : SetDeNomes) {
            /*
             * se a palavra que está no set não está na lista quer dizer que já foi removido
             * e é único
             */
            if (!listaDeNomes.contains(string)) {
                diferentes++;
            }
        }
        System.out.println("Número Total de Palavras: " + totalwords);
        System.out.println("Número de Diferentes Palavras: " + diferentes);
    }
}
