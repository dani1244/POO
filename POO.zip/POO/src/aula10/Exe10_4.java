package aula10;

import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;

public class Exe10_4 {
    public static void main(String[] args) throws FileNotFoundException {

        Scanner input = new Scanner(new FileReader("./POO/POO/src/aula10/words.txt"));

        Set<String> conjuntoDePalavras = new TreeSet<>();

        // ponto a
        while (input.hasNext()) {
            String word = input.next();
            System.out.println(word);

            // ponto b
            if (word.length() > 2) {
                conjuntoDePalavras.add(word);
            }

        }

        // ponto c
        System.out.println("Ponto CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC\nListar palavras terminadas em 's' ");
        for (String palavra : conjuntoDePalavras) {
            if (palavra.endsWith("s")) {
                System.out.println(palavra);
            }
        }


        // ponto d
        System.out.println("Ponto dddddddddddddddddd\nremover palavras que tenham outros caracteres ");
        for (String palavra : conjuntoDePalavras) {

            Pattern pattern = Pattern.compile("[\\W&&\\S]+");
            Matcher matcher = pattern.matcher(palavra);
            boolean matchFound = matcher.find();
            if (matchFound) {
                System.out.println(palavra+": tem outros caracteres");
                conjuntoDePalavras.remove(palavra);
            } else {
                System.out.println("Match not found");
            }
        }

    }
}
