package aula10;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.TreeSet;

public class Exe10_2 {
    public static void main(String[] args) {

        Map<String, List<String>> conjuntoTermos = new TreeMap<>();

        List<String> brancoValor = new ArrayList<>();
        brancoValor.add("Que tem a cor da neve");
        brancoValor.add("Descorado, pálido");
        brancoValor.add("Cor de leite");
        conjuntoTermos.put("branco", brancoValor);

        List<String> verdeValor = new ArrayList<>();
        verdeValor.add("Que tem a cor das folhas.");

        List<String> castanhoValor = new ArrayList<>();
        castanhoValor.add("Que tem a cor da terra.");
        castanhoValor.add("Cor da Universidade de Aveiro");

        List<String> vermelhoValor = new ArrayList<>();
        vermelhoValor.add("Que tem um significado qualquer.");
        vermelhoValor.add("Caderno vermelho");
        vermelhoValor.add("Cor do sangue");

        List<String> azulValor = new ArrayList<>();
        azulValor.add("azul -.- ?");
        azulValor.add("Uma esferográfica azul");
        azulValor.add("Cor de quê? ");

        List<String> azulValor2 = new ArrayList<>();
        azulValor2.add("azul novamente -.- ?");
        azulValor2.add("O que tens a dizer sobre essa cor?");

        conjuntoTermos.put("verde", verdeValor);
        conjuntoTermos.put("castanho", castanhoValor);
        conjuntoTermos.put("vermelho", vermelhoValor);
        conjuntoTermos.put("azul", azulValor);
        conjuntoTermos.remove("castanho");
        conjuntoTermos.replace("azul", azulValor2);

        //System.out.println(conjuntoTermos.containsKey("branco"));

        System.out.println(descricaoAleatoria("azul", conjuntoTermos));

    }

    public static String descricaoAleatoria(String termo, Map estrutura) {

        if (estrutura.containsKey(termo)) {
            //System.out.println("here!" + " dsd" + estrutura.get(termo));

            //pegar o valor(lista) do termo
            List<String> valor = (List<String>) estrutura.get(termo);

            /*
             * for (String frase : valor) {
             * System.out.println(frase);
             * }
             */

                //retornar um valor aleatório
            int i = new Random().nextInt(valor.size());
            return valor.get(i);

        }
        return "O termo introduzido não existe!";
    }
}
