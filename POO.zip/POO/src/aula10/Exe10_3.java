package aula10;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class Exe10_3 {
    public static void main(String[] args) {
        HashSet<String> letras = new HashSet<>();

        String texto = "Hello World";

        //colocar as letras do texto num conjunto
        for (int i = 0; i < texto.length(); i++) {

            String letra = "" + texto.charAt(i);

            letras.add(letra);
        }

        Map<String, List<Integer>> caracteres = new TreeMap<>();
        //System.out.println(letras);


        // para cada letra no conjunto ver se as letras no texto são iguais 
        for (String string : letras) {
            List<Integer> listaDeindex = new ArrayList<>();

            for (int i = 0; i < texto.length(); i++) {

                String letra = "" + texto.charAt(i);
    
                if (string.equals(letra)) {
                    //System.out.println("são iguais");
                    int index = texto.indexOf(letra);
                    if (listaDeindex.contains(index)) {
                        int ultimaOcorrencia = listaDeindex.get(listaDeindex.size()-1);
                        index = texto.indexOf(letra, ultimaOcorrencia+1);
                    }
                    listaDeindex.add(index);
                }
            }
            //System.out.println(string);
            caracteres.put(string, listaDeindex);
            

        }
        System.out.println(caracteres);
    }
}
