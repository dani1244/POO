package aula10;

import java.util.HashMap;
import java.util.Map;

public class Exe10_1 {
    public static void main(String[] args) {

        Map<String, String> conjuntoTermos = new HashMap<String, String>() {
            @Override
            public String toString() {
                StringBuilder str = new StringBuilder();

                // pegar os pare chave valor
                for (Map.Entry<String, String> entry : this.entrySet()) {
                    str.append(entry.getKey()).append(": ")
                            .append(entry.getValue()).append("\n");
                }
                str.append("\n");

                // pegar as chaves
                int i = 0;
                for (Map.Entry<String, String> entry : this.entrySet()) {
                    i++;
                    str.append(entry.getKey());
                    if (i != this.size()) {
                        str.append(", ");
                    } 
                }

                str.append("\n\n");

                // pegar os valores
                for (Map.Entry<String, String> entry : this.entrySet()) {
                    str.append(entry.getValue()).append("\n");
                }

                return str.toString();
            }

        };

        conjuntoTermos.put("branco", "Que tem a cor da neve.");
        conjuntoTermos.put("verde", "Que tem a cor das folhas.");
        conjuntoTermos.put("castanho", "Que tem a cor da terra.");
        conjuntoTermos.put("vermelho", "Que tem um significado qualquer.");
        conjuntoTermos.put("azul", "Que tem não tem significado.");
        conjuntoTermos.remove("castanho");
        conjuntoTermos.replace("azul", "azul -.- ?");

        System.out.println(conjuntoTermos.toString());
    }
}
