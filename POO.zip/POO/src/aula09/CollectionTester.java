package aula09;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.TreeSet;

public class CollectionTester {
    public static void main(String[] args) {
        int[] dim = {1000, 5000, 10000, 20000, 40000, 100000};
        String[] dataStructure = {"ArrayList", "LinkedList", "HashSet", "TreeSet"};
        double[][] results = new double[dim.length][3];
        System.out.printf("Colletcion %9d %9d %9d %9d %9d %9d", dim[0], dim[1], dim[2], dim[3], dim[4], dim[5]);

        Collection<Integer> col = new ArrayList<>();
        printPerfomance(dataStructure[0], col, results, dim);
        col = new LinkedList<>();
        printPerfomance(dataStructure[1], col, results, dim);
        
        col = new HashSet<>();
        printPerfomance(dataStructure[2], col, results, dim);
        
        col = new TreeSet<>();
        printPerfomance(dataStructure[3], col, results, dim);
        
    }

    // imprimir as perfomances de uma dada estrutura 
    public static void printPerfomance(String dataStructure, Collection<Integer> col, double[][] results, int[] dim){

        System.out.println();System.out.println(dataStructure);
        
        for (int i = 0; i < dim.length; i++) {
            double[] tmp = checkPerformace(col, i);
            for (int j = 0; j < 3; j++) {
                results[i][j] = tmp[j];
            }
        }

        String[] operation = {"add      ", "search   ", "remove   "};
        for (int i = 0; i < 3; i++) {
            System.out.print(operation[i]);
            for (int j = 0; j < dim.length; j++) {
            System.out.printf(" %9.1f", results[j][i]);
            }System.out.println();
        }
    }

    private static double[] checkPerformace(Collection<Integer> col, int DIM) {

        double start, stop, deltaSearch, deltaAdd, deltaRemove;
        // Add
        start = System.nanoTime();
        for (int i = 0; i < DIM; i++) {
            col.add(i);
        }
        stop = System.nanoTime();
        deltaAdd = (stop - start) / 1e5; //converter nano segundos para milisegundos (1e6) - coloquei (1e5 para testar os resultados)

        // search
        start = System.nanoTime();
        for (int i = 0; i < DIM; i++) {
            int n = ((int) (Math.random() * DIM));
            if (!col.contains(n)) {
                System.out.println("Not found???" + n);
            }
        }
        stop = System.nanoTime();
        deltaSearch = (stop - start) / 1e5;

        //remove
        start = System.nanoTime();
        Iterator<Integer> iterator = col.iterator();

        while (iterator.hasNext()) {
            iterator.next();
            iterator.remove();
        }

        stop  = System.nanoTime();
        deltaRemove = (stop-start)/1e5;
        double[] resultado = {deltaAdd, deltaSearch, deltaRemove};

        return resultado;
    }
}
