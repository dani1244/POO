package ExamePratico;

public class Client implements Comparable<Client> {
    String nome, localidade;

    public Client(String nome, String localidade) {
        this.nome = nome;
        this.localidade = localidade;
    }

    public String getNome() {
        return nome;
    }

    public String getLocalidade() {
        return localidade;
    }

    @Override
    public String toString() {
        return nome + ", localidade:  " + localidade;
    }

    @Override
    public int compareTo(Client o) {
        
        
        if (o == null) {
            return -1;
        }
        return this.getNome().compareTo(o.getNome());
    }
    
}
