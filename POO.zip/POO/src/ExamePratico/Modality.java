package ExamePratico;

public enum Modality {
    HIKING, KAYAK
}
