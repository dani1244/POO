package ExamePratico;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Event implements IEvent{
    LocalDate data;
    Client cliente;
    List<Activity> listaDeActividades = new ArrayList<>();
    

    public Event(Client cliente, LocalDate data) {
        this.cliente = cliente;
        this.data = data;
    }

    @Override
    public Event addActivity(Activity activity) {

        listaDeActividades.add(activity);

        return this;
    }

    @Override
    public LocalDate getDate() {

        return this.data;
    }

    @Override
    public double totalPrice() {
        int preco = 0;
        for (Activity activity : listaDeActividades) {
            
        }
        return 0;
    }

    public Client getCliente() {
        return cliente;
    }
    
}
