package ExamePratico;

public class Culture extends Activity{
    Option option;
    int participantes ;

    public Culture(Option option, int participantes) {
        this.option = option;
        this.participantes = participantes;
    }

    public enum Option{
        WINE_TASTING, ART_MUSEUM, RIVER_TOUR, ARCHITECTURAL_TOUR
    }
    
}
