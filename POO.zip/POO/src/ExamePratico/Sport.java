package ExamePratico;

import ExamePratico.Modality;

public class Sport extends Activity{
    Modality modality;
    int participantes ;

    public Sport(Modality modality, int participantes) {
        this.modality = modality;
        this.participantes = participantes;
    }

    public enum Modality{
        HIKING, KAYAK
    }
}
