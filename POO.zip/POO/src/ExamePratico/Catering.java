package ExamePratico;

public class Catering extends Activity{
    Option option;
    int participantes ;

    public Catering(Option option, int participantes) {
        this.option = option;
        this.participantes = participantes;
    }

    public enum Option{
        FULL_MENU, DRINKS_AND_SNACKS, LIGHT_BITES
    }
}
