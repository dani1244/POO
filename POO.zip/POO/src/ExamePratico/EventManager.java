package ExamePratico;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EventManager {
    String nome;
    String cliente, localidade;

    List<Client> clientes = new ArrayList<>(); 
    List<Event> events = new ArrayList<>(); 

    public EventManager(String nome) {
        this.nome = nome;
    }

    //adicionar clientes 
    public Client addClient(String nome, String localidade) {
        Client client = new Client(nome, localidade);
        clientes.add(client);

        return client;
    }

    // adicionar eventos
    public Event addEvent(Client client, LocalDate data) {
        Event event = new Event(client, data);
        events.add(event);

        return event;
    }

    // listar clientes 
    public String listClients() {
        String cliente = "";
        for (Client client : clientes) {
            cliente+=client.toString()+"\n";
        }

        return cliente;
    }

    //listar eventos 
    public String listEvents() {
        String eve = "";
        for (Event eventos : events) {
            eve+=eventos.getCliente().toString();
        }

        return eve;
    }

    // clientes com o mesmo evento

    public List<String> clientsWithEvents() {

        List<String> listaevents = new ArrayList<>();

        return listaevents;
        
    }



}
