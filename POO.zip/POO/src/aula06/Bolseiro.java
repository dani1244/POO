package aula06;

import aula07.Exe7_2.DateYMD;

public class Bolseiro extends Aluno {

    private double Bolsa;

    public Bolseiro(String nome, int iBI, DateYMD dataNasc, DateYMD iDataIns, int Bolsa) {
        super(nome, iBI, dataNasc, iDataIns);
        this.Bolsa = Bolsa;
    }

    public Bolseiro(String nome, int iBI, DateYMD dataNasc, int Bolsa) {
        super(nome, iBI, dataNasc);
        this.Bolsa = Bolsa;
    }

    public double getMonanteMensal() {
        return Bolsa;
    }

    public void setMonanteMensal(double montanteMensal) {
        if (validarMontante(montanteMensal)) {
            this.Bolsa = montanteMensal;
        }else{
            System.out.println("O montante introduzido não é válido!");
        }
        
    }

    boolean validarMontante( double Montante) {
        
        boolean valido = true;

        if (Montante < 1) {
            valido = false;
        }

        return valido;
    }

    @Override
    public String toString() {
        return super.toString() + " ,Montante Mensal: "+Bolsa;
    }

    public double getBolsa() {
        return Bolsa;
    }

    public void setBolsa(double bolsa) {
        Bolsa = bolsa;
    }

    
}