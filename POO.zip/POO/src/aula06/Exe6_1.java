package aula06;

import aula07.Exe7_2.DateYMD;

public class Exe6_1 {
    public static void main(String[] args) {

        Aluno al = new Aluno("Andreia Melo", 9855678, new DateYMD(18, 7, 1990), new DateYMD(1, 9, 2018));
        Bolseiro bls = new Bolseiro("Igor Santos", 8976543, new DateYMD(11, 5, 1985), 900);
        bls.setBolsa(1050);
        System.out.println("Aluno:" + al.getNome());
        System.out.println(al);
        System.out.println("Bolseiro:" + bls.getNome() + ", NMec: " + bls.getNmec() + ", Bolsa:" + bls.getBolsa());
        System.out.println(bls);

    }
}
