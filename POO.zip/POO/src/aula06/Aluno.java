package aula06;

import aula07.Exe7_2.DateYMD;
import java.time.LocalDate; 

public class Aluno extends Pessoa {

    // data de inscrição
    private DateYMD DataInscricao; 

    // gerar numero mecanografico
    private static int NMec = 100;
    private int nmec = 0;

    public Aluno(String nome, int iBI, DateYMD dataNasc, DateYMD iDataIns) {
        super(nome, iBI, dataNasc);

        this.nmec = NMec;
        NMec++;

        this.DataInscricao = new DateYMD(iDataIns.getDia(), iDataIns.getMes(), iDataIns.getAno());

        // TODO Auto-generated constructor stub
    }
    public Aluno(String nome, int iBI, DateYMD dataNasc) {
        super(nome, iBI, dataNasc);

        this.nmec = NMec;
        NMec++;


        this.DataInscricao = new DateYMD(LocalDate.now().getDayOfMonth(), LocalDate.now().getMonthValue(), LocalDate.now().getYear());

        // TODO Auto-generated constructor stub
    }
    public DateYMD getDataInscricao() {
        return DataInscricao;
    }
    public void setDataInscricao(DateYMD dataInscricao) {
        DataInscricao = dataInscricao;
    }
    public int getNmec() {
        return nmec;
    }
    public void setNmec(int nmec) {
        this.nmec = nmec;
    }
    @Override
    public String toString() {
        return "Aluno: "+ this.getNome()+ " ,iBI: "+ this.getCc()+" ,dataNasc: "+ this.getDataNasc()+" ,DataInscricao: " + DataInscricao + "  ,nmec: " + nmec;
    }

}