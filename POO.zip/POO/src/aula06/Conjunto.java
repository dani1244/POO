package aula06;

import java.util.ArrayList;

public class Conjunto {

    ArrayList<Integer> conjunto_lista = new ArrayList<Integer>(); // vetor de inteiros

    // inserir novo elemento
    void insert(int n) {

        if (!conjunto_lista.contains(n)) {
            conjunto_lista.add(n);
        }
    }

    // ver se um dado elemento está na lista
    boolean contains(int n) {
        boolean contem = true;

        if (!conjunto_lista.contains(n)) {
            contem = false;
        }

        return contem;
    }

    // remover um item do conjunto
    void remove(int n) {

        if (this.conjunto_lista.contains(n)) {
            int index = this.conjunto_lista.indexOf(n);// index do item no conjunto
            this.conjunto_lista.remove(index);
            System.out.println("Número removido do conjunto!");
        }
    }

    // apagar todos os numeros do conjunto
    void empty() {
        conjunto_lista.clear();
        System.out.println("Elementos apagados!");
    }

    // to string
    @Override
    public String toString() {

        StringBuilder str = new StringBuilder();

        for (int i = 0; i < this.conjunto_lista.size(); i++) {
            str.append(this.conjunto_lista.get(i) + " ");
        }

        return str.toString();
    }

    // tamanho do conjunto
    int size() {
        int tamanho = this.conjunto_lista.size();

        return tamanho;
    }

    // combinar listas
    Conjunto combine(Conjunto add) {

        ArrayList add2 = add.getConjunto();
        Conjunto uniao = new Conjunto();
        // add os elementos da classe 1
        for (int i = 0; i < this.conjunto_lista.size(); i++) {
            uniao.insert(this.conjunto_lista.get(i));
        }

        Integer num;

        // add os elementos do outro conjunto
        for (int i = 0; i < add2.size(); i++) {
            // System.out.println(add2.get(i));

            num = (Integer) add2.get(i);

            if (!this.conjunto_lista.contains(num)) {
                uniao.insert(num);
            }
        }

        return uniao;
    }

    // subtract
    Conjunto subtract(Conjunto dif) {
        Conjunto diferenca = new Conjunto();

        ArrayList conj = dif.getConjunto();

        // add os elementos no conjunto
        for (int i = 0; i < this.conjunto_lista.size(); i++) {

            if (!conj.contains(this.conjunto_lista.get(i))) {
                diferenca.insert(this.conjunto_lista.get(i));
            }
        }

        return diferenca;
    }

    // intersessão
    Conjunto intersect(Conjunto inter) {
        Conjunto intersect = new Conjunto();

        ArrayList conj = inter.getConjunto();

        // add os elementos no conjunto
        for (int i = 0; i < conj.size(); i++) {

            int num = (Integer) conj.get(i);

            if (this.conjunto_lista.contains(num)) {
                intersect.insert(num);
            }
        }

        return intersect;
    }

    private ArrayList<Integer> getConjunto() {
        return this.conjunto_lista;
    }

}