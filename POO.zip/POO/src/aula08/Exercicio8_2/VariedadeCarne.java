package aula08.Exercicio8_2;

public enum VariedadeCarne{
    VACA, PORCO, PERU, FRANGO, OUTRA
}