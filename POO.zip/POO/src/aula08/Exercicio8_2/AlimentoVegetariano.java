package aula08.Exercicio8_2;

public interface AlimentoVegetariano {
    
}
