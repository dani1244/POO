package aula08.Exercicio8_2;

import java.util.ArrayList;

public class PratoDieta extends Prato{
    double limiteDeCalorias;

    public PratoDieta(String nome, double limiteDeCalorias) {
        super(nome);
        this.limiteDeCalorias = limiteDeCalorias;
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getLimiteDeCalorias() {
        return limiteDeCalorias;
    }

    public void setLimiteDeCalorias(double limiteDeCalorias) {
        this.limiteDeCalorias = limiteDeCalorias;
    }

    public ArrayList<Alimentos> getIngrediente() {
        return composicao;
    }
    
    @Override
    public boolean addIngrediente(Alimentos alimento) {
        boolean adicionado = true;

        if ((calorias() + alimento.calorias) > limiteDeCalorias) {
            adicionado = false;
        }else{
            this.composicao.add(alimento);
        }

        return adicionado;
    }
    
    @Override
    public void removeIngrediente(Alimentos alimento) {
        if (this.composicao.contains(alimento)) {
            int indexDoingrediente = composicao.indexOf(alimento);
            this.composicao.remove(indexDoingrediente);
        } else {
            System.out.println("Alimento não encontrado!");
        }
        
    }



    //determinar o peso total do prato
    @Override
    public double pesoTotal() {

        double pesototal = 0;
        for (int i = 0; i < this.composicao.size(); i++) {
            pesototal +=  this.composicao.get(i).peso;
          }

        return pesototal;
    }


    //total de proteinas
    @Override
    public double proteinas() {

        double total = 0;
        for (int i = 0; i < this.composicao.size(); i++) {
            total +=  this.composicao.get(i).proteinas;
          }

        return total;
    }

    
    @Override
    public String toString() {
        return "PratoVegetariano - nome: "+nome+", limite de calorias: "+limiteDeCalorias+", peso total: "+pesoTotal()+", calorias: "+calorias()+", proteinas: "+proteinas();
    }
}
