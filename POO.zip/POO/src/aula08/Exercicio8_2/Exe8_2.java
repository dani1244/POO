package aula08.Exercicio8_2;

import java.util.ArrayList;
import java.util.Scanner;

import javax.lang.model.util.ElementScanner6;

public class Exe8_2 {
    public static void main(String[] args) {

        Scanner user_input = new Scanner(System.in);

        Ementa ementa = new Ementa("Especial Primavera", "Snack da UA");

        ArrayList<Prato> pratos = new ArrayList<Prato>();
        ArrayList<Alimentos> alimentos = new ArrayList<Alimentos>();

        while (true) {
            System.out.println(
                    "--Ingrediente:\n1 - Adicionar Carne\n2 - Adicionar Peixe\n3 - Adicionar Cereal\n4 - Adicionar Legume\n--Prato:\n5 - Criar Prato\n6 - Apagar Prato\n7 - Selecionar Pratol\n--Ementa:\n8 - Adicionar Prato\n9 - Remover Prato\n10 - Imprimir Ementa\n\n 0 - exit");

            int operacao = user_input.nextInt();

            // Adicionar Carne
            if (operacao == 1) {

                System.out.println("introduza Variedade: ");
                System.out.println("lista de variedades:\n0 - vaca;\n1 - porco;\n2 - peru;\n3 - frango;\n4 - outra;");
                int escolha = user_input.nextInt();
                VariedadeCarne variedade ;
                switch (escolha) {
                    case 0:

                     variedade = VariedadeCarne.VACA;
                        break;
                    case 1:

                     variedade = VariedadeCarne.PORCO;
                        break;
                    case 2:

                    variedade = VariedadeCarne.PERU;
                        break;
                    case 3:

                    variedade = VariedadeCarne.FRANGO;
                        break;
         
                    default:
                    variedade = VariedadeCarne.OUTRA;
                        break;
                }


                System.out.println("introduza proteina: ");
                Double proteinas = user_input.nextDouble();

                System.out.println("introduza caloria: ");
                Double calorias = user_input.nextDouble();

                System.out.println("introduza peso: ");
                Double peso = user_input.nextDouble();

                Carne carne = new Carne(variedade, proteinas, calorias, peso);

                alimentos.add(carne);
                System.out.println("[----Adicionado!----]");

                continue;
            }

            // Adicionar Peixe
            if (operacao == 2) {

                System.out.println("introduza tipo: ");
                System.out.println("lista de tipos:\n0 - Congelado;\n1 - Fresco;");
                int escolha = user_input.nextInt();
                TipoPeixe tipo ;
                switch (escolha) {
                    case 0:

                     tipo = TipoPeixe.CONGELADO;
                        break;
                    case 1:

                     tipo = TipoPeixe.FRESCO;
                        break;
         
                    default:
                    tipo = TipoPeixe.FRESCO;
                        break;
                }

                System.out.println("introduza proteina: ");
                Double proteinas = user_input.nextDouble();

                System.out.println("introduza caloria: ");
                Double calorias = user_input.nextDouble();

                System.out.println("introduza peso: ");
                Double peso = user_input.nextDouble();

                Peixe peixe = new Peixe(tipo, proteinas, calorias, peso);

                alimentos.add(peixe);
                System.out.println("[----Adicionado!----]");

                continue;

            }

            // Adicionar Cereal
            if (operacao == 3) {

                System.out.println("introduza nome: ");
                String nome = user_input.next();

                System.out.println("introduza proteina: ");
                Double proteinas = user_input.nextDouble();

                System.out.println("introduza caloria: ");
                Double calorias = user_input.nextDouble();

                System.out.println("introduza peso: ");
                Double peso = user_input.nextDouble();

                Cereal cereal = new Cereal(nome, proteinas, calorias, peso);

                alimentos.add(cereal);
                System.out.println("[----Adicionado!----]");

                continue;

            }

            // Adicionar Legume
            if (operacao == 4) {

                System.out.println("introduza nome: ");
                String nome = user_input.next();

                System.out.println("introduza proteina: ");
                Double proteinas = user_input.nextDouble();

                System.out.println("introduza caloria: ");
                Double calorias = user_input.nextDouble();

                System.out.println("introduza peso: ");
                Double peso = user_input.nextDouble();

                Legume legume = new Legume(nome, proteinas, calorias, peso);

                alimentos.add(legume);
                System.out.println("[----Adicionado!----]");

                continue;

            }

            // Criar prato
            if (operacao == 5) {
                System.out.println("que tipo de prato: " + "\n1 - Normal\n2 - Vegetariano\n3 - Dieta");

                int tipoPrato = user_input.nextInt();

                if (tipoPrato == 1) {
                    System.out.println("introduza o nome do prato: ");
                    String nome = user_input.next();user_input.nextLine();

                    Prato prato = new Prato(nome);
                    pratos.add(prato);

                    System.out.println("[----Criado!----]");

                    continue;
                }
                else if (tipoPrato == 2) {
                    System.out.println("introduza o nome do prato: ");
                    String nome = user_input.next();user_input.nextLine();

                    PratoVegetariano pratoVegetariano = new PratoVegetariano(nome);
                    pratos.add(pratoVegetariano);

                    System.out.println("[----Criado!----]");

                    continue;
                }
                else if (tipoPrato == 3) {
                    System.out.println("introduza o nome do prato: ");
                    String nome = user_input.next();user_input.nextLine();
                    System.out.println("Limite de caloria: ");
                    Double limiteCaloria = user_input.nextDouble();

                    PratoDieta pratoDieta = new PratoDieta(nome, limiteCaloria);
                    pratos.add(pratoDieta);

                    System.out.println("[----Criado!----]");

                    continue;
                }else{
                    System.out.println("As escolhas devem ser 1, 2 ou 3");
                }



            }

            // apagar prato
            if (operacao == 6) {
                System.out.println("Lista de pratos criados:");

                listarPratos(pratos);

                System.out.println("introduza o index do prato que deseja retirar: ");
                int index = user_input.nextInt();
                pratos.remove(index);
                System.out.println("[----Prato removido----]");

                continue;
            }

            // selecionar prato

            if (pratos.size() == 0) {
                System.out.println("Crie pratos antes de selcionar");
                continue;
            }


            if (operacao == 7) {
                System.out.println("Lista de pratos criados: ");
                listarPratos(pratos);

                System.out.println("introduza o index do prato que deseja selecionar: ");
                int indexPrato = user_input.nextInt();
                Prato pratoselecionado = pratos.get(indexPrato);
                System.out.println("Prato selecionado: " + pratoselecionado);

                System.out.println("lista de ingredientes: ");
                listarAlimentos(alimentos);

                System.out.println("Que ações deseja realizar:");
                System.out.println("\n1 - Adicionar Ingrediente\n2 - Eliminar Ingrediente\n");
                int accao = user_input.nextInt();

                // adicionar ingredientes
                if (accao == 1) {
                    do {
                        System.out.println("Selecione o index do ingrediente que deseja adicionar:");
                        int indexingre = user_input.nextInt();
                        Alimentos ingredienteselecionado = alimentos.get(indexingre);

                        pratoselecionado.addIngrediente(ingredienteselecionado);
                        System.out.println("[----adicionado!----]");

                        System.out.println("digite '00' se quiser parar:");
                        indexingre = user_input.nextInt();

                        if (indexingre == 00) {
                            pratos.set(indexPrato, pratoselecionado);
                            System.out.println("[----Ingredientes adicionado!----]");
                            break;
                        }

                    } while (true);

                } else {
                    // remover ingredientes

                    do {
                        System.out.println("Selecione o index do ingrediente que deseja Eliminar:");
                        int indexingre = user_input.nextInt();
                        Alimentos ingredienteselecionado = alimentos.get(indexingre);

                        pratoselecionado.removeIngrediente(ingredienteselecionado);
                        System.out.println("[----removido!----]");

                        System.out.println("digite '00' se quiser parar:");
                        indexingre = user_input.nextInt();

                        if (indexingre == 00) {
                            pratos.set(indexPrato, pratoselecionado);
                            System.out.println("[----Ingredientes adicionado!----]");
                            break;
                        }

                    } while (true);

                }

                continue;

            }

            // adicionar prato à ementa
            if (operacao == 8) {

                if (pratos.size() == 0) {
                    System.out.println("Não há pratos");
                    continue;
                }

                System.out.println("Adicionar Prato à ementa " + ementa.getNome());
                System.out.println("selecione o prato abaixo pelo seu index: ");
                listarPratos(pratos);

                int index = user_input.nextInt();
                Prato prato = pratos.get(index);
                ementa.setPrato(prato);
                System.out.println("[----Adicionado!----]");
                continue;
            }

            // remover prato da ementa
            if (operacao == 9) {

                
                if (pratos.size() == 0) {
                    System.out.println("Não há pratos");
                    continue;
                }

                System.out.println("Lista de pratos na ementa " + ementa.getNome() + ":");

                for (int i = 0; i < ementa.getPratos().size(); i++) {
                    System.out.println("Prato -" + i + "- " + ementa.getPratos().get(i));
                }

                System.out.println("introduza o index do prato que deseja retirar: ");
                int index = user_input.nextInt();
                ementa.removerPratos(index);
                System.out.println("[----Prato removido----]");

                continue;

            }

            // imprimir Ementa
            if (operacao == 10) {
                ementa.toString();

                for (Prato i : ementa.getPratos()) {
                    i.toString();
                }

                continue;
            }

            if (operacao == 0) {
                break;
            }
        }

    }

    public static void listarPratos(ArrayList<Prato> prato) {

        for (int i = 0; i < prato.size(); i++) {
            System.out.println("Prato -" + i + "- " + prato.get(i));
        }
    }

    public static void listarAlimentos(ArrayList<Alimentos> alimentos) {

        for (int i = 0; i < alimentos.size(); i++) {
            System.out.println("Alimento -" + i + "- " + alimentos.get(i));
        }
    }
}
