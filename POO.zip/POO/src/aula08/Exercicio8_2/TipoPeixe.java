package aula08.Exercicio8_2;

public enum TipoPeixe {
    CONGELADO, FRESCO
}
