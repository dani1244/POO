package aula08.Exercicio8_2;

public abstract class Alimentos {
    double proteinas, calorias, peso;


    abstract public double getProteinas();
    

    abstract public void setProteinas(double proteinas);
     
    abstract public double getCalorias();

    abstract public void setCalorias(double calorias);
     

    abstract public double getPeso();
     

    abstract public void setPeso(double peso);

    public double getTotalCalorias() {

        return this.getCalorias()*(this.peso/100);
    }
    public double getTotalProteina() {

        return this.getProteinas()*(this.peso/100);
    }
    

    @Override
    public String toString() {
        return " calorias:" + calorias +"/100gr"+", total de calorias: " + getTotalCalorias()+ ", peso: " + peso + ", proteinas: " + proteinas+"100gr "+", total de proteinas: " + getTotalProteina();
    }

    

}
