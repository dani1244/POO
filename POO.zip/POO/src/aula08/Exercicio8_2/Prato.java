package aula08.Exercicio8_2;

import java.util.ArrayList;

public class Prato  implements Comparable<Prato>{

    protected String nome;
    private DiaSemana diaSemana ;
    protected ArrayList<Alimentos> composicao = new ArrayList<Alimentos>();


    public Prato(String nome) {
        this.nome = nome;
    }

    public DiaSemana getDiaSemana() {
        return diaSemana;
    }

    public void setDiaSemana(DiaSemana diaSemana) {
        this.diaSemana = diaSemana;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<Alimentos> getIngrediente() {
        return composicao;
    }

    
    public boolean addIngrediente(Alimentos alimento) {
        boolean adicionado = true;

        try {

            this.composicao.add(alimento);
        } catch (Exception e) {
            adicionado = false;
        }

        return adicionado;
    }

  
    public void removeIngrediente(Alimentos alimento) {
        if (this.composicao.contains(alimento)) {
            int indexDoingrediente = composicao.indexOf(alimento);
            this.composicao.remove(indexDoingrediente);
        } else {
            System.out.println("Alimento não encontrado!");
        }

    }

    // determinar o peso total do prato
    
    public double pesoTotal() {

        double pesototal = 0;
        for (int i = 0; i < this.composicao.size(); i++) {
            pesototal += this.composicao.get(i).peso;
        }

        return pesototal;
    }

    //determinar o total de calorias no prato
    public double calorias() {
        
        double total = 0;
        for (int i = 0; i < this.composicao.size(); i++) {
            total +=  this.composicao.get(i).getTotalCalorias();
          }

        return total;
    }

    // total de proteinas
   
    public double proteinas() {

        double total = 0;
        for (int i = 0; i < this.composicao.size(); i++) {
            total += this.composicao.get(i).getTotalProteina();
        }

        return total;
    }
    @Override
    public int compareTo(Prato o) {
        // comparar os pratos baseados em calorias

        int result = 0;

        if (this.calorias() > o.calorias()) {
            result = 1;
        }else if(this.calorias() < o.calorias()){
            result = -1;
        } else {
            result = 0;
        }

        return result;
    }

    @Override
    public String toString() {
        return "PratoVegetariano - nome: " + nome + ", peso total: " + pesoTotal() + ", calorias: " + calorias()
                + ", proteinas: " + proteinas();
    }

}
