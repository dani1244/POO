package aula08.Exercicio8_2;

import java.util.ArrayList;

public class Ementa {
    String nome, local;
    DiaSemana diaSemana;
    
    ArrayList<Prato> Pratos = new ArrayList<Prato>();

    public Ementa(String nome, String local) {
        this.nome = nome;
        this.local = local;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public ArrayList<Prato> getPratos() {
        return Pratos;
    }

        //adicionar um prato a lista
    public void setPrato(Prato prato) {
        this.Pratos.add(prato);
    }

    //adicionar um prato com dia à lista
    public void setPrato(Prato prato, DiaSemana dia) {
        this.Pratos.add(prato);
        int index = Pratos.indexOf(prato);
        Prato prato2 = Pratos.get(index);
        prato2.setDiaSemana(dia);
        this.Pratos.set(index, prato2);
    }
    public void removerPratos(int  indexDoPrato) {
        this.Pratos.remove(indexDoPrato);
    }

    @Override
    public String toString() {

        String s = "";
        int i = 0;
        for (Prato prato : Pratos) {
            int tot = prato.composicao.size();
            DiaSemana dia = prato.getDiaSemana();

            if ((prato instanceof PratoVegetariano)) {
                s += String.format("Prato 'Combinado n.%s', composto por %d Ingredientes - Prato Vegetariano, dia %s %n", i, tot, dia);
                i++;
            }else if(prato instanceof PratoDieta){
                s += String.format("Prato 'Combinado n.%s', composto por %d Ingredientes - Dieta (%f), dia %s %n", i, tot, prato.calorias(), dia);
                i++;
            }else{
                s += String.format("Prato 'Combinado n.%s', composto por %d Ingredientes, dia %s %n", i, tot, dia);
                i++;
            }



        }

        return "Ementa: " + nome + ", local: " + local +", \n"+s;
    }

}


