package aula08.Exercicio8_1;

public class AutomovelLigeiro extends Viatura {

    int numeroDoQuadro;
    double capacidadeBagageira;


        //construtor

        public AutomovelLigeiro( String matricula,String marca, String modelo, int potencia, int numeroDoQuadro, double capacidadeBagageira) {

            this.matricula = matricula;
            this.marca = marca;
            this.modelo = modelo;
            this.potencia = potencia;
            this.numeroDoQuadro = numeroDoQuadro;
            this.capacidadeBagageira = capacidadeBagageira;
        }




    public int getNumeroDoQuadro() {
        return numeroDoQuadro;
    }
    public void setNumeroDoQuadro(int numeroDoQuadro) {
        this.numeroDoQuadro = numeroDoQuadro;
    }
    public double getCapacidadeBagageira() {
        return capacidadeBagageira;
    }
    public void setCapacidadeBagageira(double capacidadeBagageira) {
        this.capacidadeBagageira = capacidadeBagageira;
    }
    @Override
    public String toString() {
        return  "Automovél Ligeiro " +  super.toString() + ", capacidadeBagageira: " + capacidadeBagageira + ", numeroDoQuadro: " + numeroDoQuadro;
    }
    
    


}
