package aula08.Exercicio8_1;

public class PesadoPassageiros  extends Viatura{
    int numeroDoQuadro, numeroMaximoDePassageiros;
    double peso;

    public PesadoPassageiros( String matricula,String marca, String modelo, int potencia, int numeroDoQuadro, int numeroMaximoDePassageiros, double peso) {

        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.potencia = potencia;
        this.numeroDoQuadro = numeroDoQuadro;
        this.numeroMaximoDePassageiros = numeroMaximoDePassageiros;
        this.peso = peso;
    }


    public int getNumeroDoQuadro() {
        return numeroDoQuadro;
    }
    public void setNumeroDoQuadro(int numeroDoQuadro) {
        this.numeroDoQuadro = numeroDoQuadro;
    }
    public int getNumeroMaximoDePassageiros() {
        return numeroMaximoDePassageiros;
    }
    public void setNumeroMaximoDePassageiros(int numeroMaximoDePassageiros) {
        this.numeroMaximoDePassageiros = numeroMaximoDePassageiros;
    }
    public double getPeso() {
        return peso;
    }
    public void setPeso(double peso) {
        this.peso = peso;
    }
    @Override
    public String toString() {
        return  "Pesado de passageiros " +  super.toString() + ", numeroDoQuadro: " + numeroDoQuadro + ", numeroMaximoDePassageiros: "
                + numeroMaximoDePassageiros + ", peso: " + peso;
    }

    


}