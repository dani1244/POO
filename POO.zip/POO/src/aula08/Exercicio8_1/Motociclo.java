package aula08.Exercicio8_1;

public class Motociclo extends Viatura {
    String tipo;

    public Motociclo( String matricula,String marca, String modelo, int potencia, String tipo) {

        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.potencia = potencia;
        this.tipo = tipo;  //desportivo ou estrada
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return  "Motociclo " +  super.toString() +  ", tipo: " + tipo;
    }

    

    
}
