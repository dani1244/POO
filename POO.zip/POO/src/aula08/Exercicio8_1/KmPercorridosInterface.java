package aula08.Exercicio8_1;

public interface KmPercorridosInterface {
    void trajeto(int quilometros);
    int ultimoTrajeto();
    int distanciaTotal();    
}
