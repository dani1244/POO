package aula08.Exercicio8_1;

public class PesadoMercadorias extends
 Viatura{
    int numeroDoQuadro, cargaMaxima;
    double peso;


    //construtor 

    public PesadoMercadorias( String matricula,String marca, String modelo, int potencia, int numeroDoQuadro, int cargaMaxima, double peso) {

        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.potencia = potencia;
        this.numeroDoQuadro = numeroDoQuadro;
        this.cargaMaxima = cargaMaxima;
        this.peso = peso;
    }

    
    public int getNumeroDoQuadro() {
        return numeroDoQuadro;
    }
    public void setNumeroDoQuadro(int numeroDoQuadro) {
        this.numeroDoQuadro = numeroDoQuadro;
    }
    public int getCargaMaxima() {
        return cargaMaxima;
    }
    public void setCargaMaxima(int cargaMaxima) {
        this.cargaMaxima = cargaMaxima;
    }
    public double getPeso() {
        return peso;
    }
    public void setPeso(double peso) {
        this.peso = peso;
    }
    @Override
    public String toString() {
        return  "Pesado de mercadoria " +  super.toString() + ", cargaMaxima: " + cargaMaxima + ", numeroDoQuadro: " + numeroDoQuadro + ", peso: " + peso;
    }


}
