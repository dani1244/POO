package aula08.Exercicio8_1;

    import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
public class Exercicio8_1 {

    public static void main(String[] args) {
        

        Scanner user_input = new Scanner(System.in);

        EmpresaAluguel empresa = new EmpresaAluguel("Nome da empresa", "empresa@gmail.com", 1452145);

        Motociclo  moto1 = new Motociclo("21-12-14", "Sanya", "SY125-24", 195, "estrada");
        Motociclo  moto2 = new Motociclo("12-9-14", "Sanya", "SY8-XLY72", 195, "estrada");

        AutomovelLigeiro aLigeiro1 = new AutomovelLigeiro("03-11-2022", "Toyota", "Corolla", 220, 155555555, 50);

        AutomovelLigeiro aLigeiro2 = new AutomovelLigeiro("20-11-2022", "Toyota", "Corolla", 253, 15333355, 47);


        moto1.trajeto(20);
        System.out.println(moto1.distanciaTotal());

            moto1.trajeto(46);
        moto2.trajeto(55);
        System.out.println(moto2.distanciaTotal());

        System.out.println(moto1.distanciaTotal()+",  "+moto1.ultimoTrajeto());

        System.out.println("A viatura com mais kilometros percoridos é a "+moto1.toString());
        

        AutomovelLigeiroEletrico ale1 = new AutomovelLigeiroEletrico("03-11-2022", "Toyota", "Corolla", 220, 155555555, 50);

        ale1.carregar(50);
        System.out.println("carga: "+ale1.autonomia());ale1.carregar(60);
        System.out.println(ale1.autonomia());ale1.carregar(-40);System.out.println(ale1.autonomia());ale1.carregar(10);System.out.println(ale1.autonomia());

        System.out.println("---------------------------------------------------------------------------");

        ArrayList<Viatura> carros = new ArrayList<Viatura>();

        carros.add(ale1);carros.add(moto1);carros.add(moto2);carros.add(aLigeiro1);carros.add(aLigeiro2);
        
        for (Viatura c : carros) {
            System.out.println(c);
        }
        System.out.println("----------------------------------------------------------------------------------");
        System.out.println("---------------------------Ordenado por potência----------------------------------");
        System.out.println("----------------------------------------------------------------------------------");
        
        Collections.sort(carros, new Comparator<Viatura>() {

            @Override
            public int compare(Viatura o1, Viatura o2) {
                // TODO Auto-generated method stub
                return Integer.valueOf(o1.compareTo(o2));
            }
            
        });

        for (Viatura c : carros) {
            System.out.println(c);
        }
    }
}
