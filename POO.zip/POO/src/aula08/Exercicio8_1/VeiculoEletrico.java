package aula08.Exercicio8_1;

public interface VeiculoEletrico {
    int autonomia();
    void carregar(int percentagem);
    
}
