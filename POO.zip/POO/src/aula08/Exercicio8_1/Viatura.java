package aula08.Exercicio8_1;

public class Viatura implements KmPercorridosInterface, Comparable<Viatura> {
    String matricula, marca, modelo;
    int potencia;

    int ultimoTrajeto, distanciaTotal, trajeto;

    public void trajeto(int quilometros) {
        this.ultimoTrajeto = quilometros;
        this.distanciaTotal += quilometros;

    }

    public int ultimoTrajeto() {
        return this.ultimoTrajeto;
    }

    public int distanciaTotal() {
        return this.distanciaTotal;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }

    //validar a matricula
    public static boolean validarMatricula(String matricula){

        boolean valido = true;

        if (matricula.length() < 4) {
            valido = false;
        }

        return valido;
    }

    @Override
    public String toString() {
        return "matricula: " + matricula + ", marca: " + marca + ", distanciaTotal: " + distanciaTotal
                + ", modelo: " + modelo + ", potencia: " + potencia;
    }

    @Override
    public int compareTo(Viatura o) {
        
        // comparar os pratos baseados em calorias

        int result = 0;

        if (this.potencia > o.potencia) {
            result = 1;
        }else if(this.potencia < o.potencia){
            result = -1;
        } else {
            result = 0;
        }

        return result;
     
    }

}
