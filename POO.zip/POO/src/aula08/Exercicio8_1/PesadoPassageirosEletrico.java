package aula08.Exercicio8_1;

public class PesadoPassageirosEletrico  extends PesadoPassageiros implements VeiculoEletrico{

    private int autonomia;

    public PesadoPassageirosEletrico(String matricula, String marca, String modelo, int potencia, int numeroDoQuadro,
            int numeroMaximoDePassageiros, double peso) {
        super(matricula, marca, modelo, potencia, numeroDoQuadro, numeroMaximoDePassageiros, peso);
        
    }

    
    @Override
    public int autonomia() {
        
        return this.autonomia;
    }

    @Override
    public void carregar(int percentagem) {
        if ((this.autonomia + percentagem) >= 100) {
            this.autonomia = 100;
            System.out.println("Carga completa!");
            System.out.println("Autonomia: " + this.autonomia + "%");
        } else if ((percentagem + this.autonomia) < 0) {
            this.autonomia += 0;
            System.out.println("Valor da carga insuficiente!");
            System.out.println("Autonomia: " + this.autonomia + "%");
        } else {
            this.autonomia += percentagem;
            System.out.println("Carregamento feito!");
            System.out.println("Autonomia: " + this.autonomia + "%");

        }
    }


    @Override
    public String toString() {
        return  "Pesado de passageiros eletricos " +  super.toString() + ", autonomia: " + autonomia + "%";
    }
    
}
