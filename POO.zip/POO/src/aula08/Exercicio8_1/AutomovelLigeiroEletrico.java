package aula08.Exercicio8_1;

public class AutomovelLigeiroEletrico extends AutomovelLigeiro implements VeiculoEletrico {

    private int autonomia;

    public AutomovelLigeiroEletrico(String matricula, String marca, String modelo, int potencia, int numeroDoQuadro,
            double capacidadeBagageira) {
        super(matricula, marca, modelo, potencia, numeroDoQuadro, capacidadeBagageira);
        // TODO Auto-generated constructor stub
    }

    @Override
    public int autonomia() {

        return this.autonomia;
    }

 
    public void carregar(int percentagem) {
        if ((this.autonomia + percentagem) >= 100) {
            this.autonomia = 100;
            System.out.println("Carga completa!");
            System.out.println("Autonomia: " + this.autonomia + "%");
        } else if ((percentagem + this.autonomia) < 0) {
            this.autonomia += 0;
            System.out.println("Valor da carga insuficiente!");
            System.out.println("Autonomia: " + this.autonomia + "%");
        } else {
            this.autonomia += percentagem;
            System.out.println("Carregamento feito!");
            System.out.println("Autonomia: " + this.autonomia + "%");

        }
    }

    @Override
    public String toString() {
        return  "Automovél ligeiro eletrico " +  super.toString() + ", autonomia: " + autonomia + "%";
    }

}
