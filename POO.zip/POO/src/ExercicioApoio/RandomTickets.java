package ExercicioApoio;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Map.Entry;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class RandomTickets {

    List<Festival> listaDeFestivais = listaDeFestivais();

    Map<Person, List<Festival>> PessoasFest = new HashMap<>();
    Map<Person, List<Integer>> sorteioInt = new HashMap<>();

    public void getRandomTicket(Person pessoa) {

        int ri = (int) (Math.random() * listaDeFestivais.size());// fest aleatorio
        int bi = (int) (Math.random() * 2);// num aleatorio

        if (PessoasFest.containsKey(pessoa)) {

            Festival festAleat = (Festival) listaDeFestivais.get(ri);
            List<Integer> listaInt = sorteioInt.get(pessoa);

            if (PessoasFest.get(pessoa).contains(festAleat)) {
                int posfest = PessoasFest.get(pessoa).indexOf(festAleat);
                listaDeFestivais.get(listaDeFestivais.indexOf(festAleat)).decrementarNbilhete(bi);//.decrementarNbilhete(bi);
                int numbilhete = listaInt.get(posfest);
                listaInt.set(posfest, numbilhete + bi);
            }else{
                PessoasFest.get(pessoa).add(festAleat);
                sorteioInt.get(pessoa).add(bi);
                listaDeFestivais.get(listaDeFestivais.indexOf(festAleat)).decrementarNbilhete(bi);
                festAleat.decrementarNbilhete(bi);
            }

        } else {
            List<Festival> listafet = new ArrayList<>();
            List<Integer> listaInt = new ArrayList<>();

            Festival festAleat = (Festival) listaDeFestivais.get(ri);
            listaInt.add(bi);
            listaDeFestivais.get(listaDeFestivais.indexOf(festAleat)).decrementarNbilhete(bi);
            festAleat.decrementarNbilhete(bi);
            listafet.add(festAleat);
            PessoasFest.put(pessoa, listafet);
            sorteioInt.put(pessoa, listaInt);
        }

    }

    public void listPersons() {
        for (Entry<Person, List<Festival>> festival : PessoasFest.entrySet()) {
            System.out.println(festival);
        }

    }

    public void listAvailableTickets() {
        for (Festival festival : listaDeFestivais) {
            System.out.println(festival);
        }
    }

    // colocar os festivais por objectos na lista
    private static List<Festival> listaDeFestivais() {
        List<Festival> listaFestival = new ArrayList<>();
        try (
                Scanner input = new Scanner(new FileReader("./POO/POO/src/ExercicioApoio/Lista_festivais.txt")))

        {
            input.nextLine();
            while (input.hasNext()) {
                String festival = input.nextLine();

                String[] evento = festival.split("\t"); // split por tab

                listaFestival
                        .add(new Festival(evento[0], evento[1], evento[2], evento[3], Integer.parseInt(evento[4])));

            }
        } catch (Exception e) {
            System.out.println("Ficheiro não encontrado!");
        }
        return listaFestival;
    }

}
