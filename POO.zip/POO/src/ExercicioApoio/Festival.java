package ExercicioApoio;

import aula07.Exe7_2.Date;
import aula07.Exe7_2.DateYMD;

public class Festival {
    Date dataIni, dataFim;
    String nome, local;
    private int nBilhete;

    public Festival(String dataIni, String dataFim, String nome, String local, int nBilhete) {
        this.dataIni = StringToDate(dataIni);
        this.dataFim = StringToDate(dataFim);
        this.nome = nome;
        this.local = local;
        this.nBilhete = nBilhete;
    }

   protected boolean decrementarNbilhete() {

        if (this.nBilhete > 0) {
            this.nBilhete--;
            return true;
        } else {
            return false;
        }
    }
   protected boolean decrementarNbilhete(int qt) {

        if (this.nBilhete < 0) {
            this.nBilhete-=qt;
            return true;
        } else {
            return false;
        }
    }

    private static DateYMD StringToDate(String data) {

        String[] datastr = data.split("-");

        DateYMD dataymd = new DateYMD(Integer.parseInt(datastr[0]), Integer.parseInt(datastr[1]),
                Integer.parseInt(datastr[2]));

        return dataymd;

    }

    public int getnBilhete() {
        return nBilhete;
    }

    @Override
    public String toString() {
        return nome + ", "+local+", data de inicio: "+dataIni+", data de fim: "+dataFim+", número de bilhetes: "+nBilhete;

                
    }
}
